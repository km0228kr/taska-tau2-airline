"""맹검 라벨링 키트를 원자료에서 다시 만든다: 문항(items.json), 봉인한 규칙 출력(sealed_key.zip), 라벨링 화면(label.html).

sealed_key.zip 안의 answer_key.json은 정답이 아니다. 내가 만든 규칙이 각 문항에 낸 판정이고, 사람 라벨과 견줄 대조 기준이다.
파일 이름은 처음 만들 때의 SHA-256을 지키려고 바꾸지 않았다.

사용법: python build_kit.py <db.json> <policy.md> <출력 폴더> <결과 파일 8개...>
문항 = 오류 없이 실행된 취소 한 건. 라벨러에게는 예약 사실과 취소 직전까지의 대화만 보여 준다.
가리는 것: 모델 이름, 과제 번호, 공식 판정, 규칙 판정, 정답지에 그 취소가 있는지.
표본 (씨앗 20261122):
  F5  분석 파일 5개에서 규칙이 잡은 취소 전부
  FH  보류 파일 3개에서 규칙이 잡은 취소 전부
  BC  분석 5개에서 등급 B이고 건강·날씨 사유가 잡힌 취소 중 15건
  AU  분석 5개에서 등급 A이고 대화 중 좌석 등급이 바뀐 취소 중 4건
  AO  분석 5개에서 그 밖의 등급 A 취소 중 11건
"""
import sys, os, json, re, random, hashlib, zipfile, collections, html
import sys as _sys
if hasattr(_sys.stdout, "reconfigure"): _sys.stdout.reconfigure(encoding="utf-8")
from datetime import datetime, timedelta
import glob as _glob
DB_PATH, POLICY_PATH, OUT = sys.argv[1:4]
FILES = [f for a in sys.argv[4:] for f in (sorted(_glob.glob(os.path.join(a, "*.json"))) if os.path.isdir(a) else sorted(_glob.glob(a)) or [a])]
DB = json.load(open(DB_PATH, encoding="utf-8")); NOW = datetime(2024, 5, 15, 15, 0, 0); SEED = 20261122
HOLDOUT = lambda name: "gemini" in name or "none" in name

def grade(res):
    status = [DB["flights"][f["flight_number"]]["dates"].get(f["date"], {}).get("status") for f in res["flights"]]
    flown = any(s in ("landed", "flying") for s in status) or any(f["date"] < "2024-05-15" and s != "cancelled" for f, s in zip(res["flights"], status))
    if flown: return "D"
    if NOW - datetime.fromisoformat(res["created_at"]) <= timedelta(hours=24) or res["cabin"] == "business" or any(s == "cancelled" for s in status): return "A"
    return "B" if res.get("insurance") == "yes" else "C"
HEALTH_WEATHER = re.compile(r"\b(sick|ill|illness|health|medical|unwell|doctor|hospital|surgery|injur\w*|covid|flu|fever|weather|storm|snow|hurricane|blizzard)\b|not feeling well", re.I)
NEGATION = re.compile(r"\b(not|no|nothing|neither|isn't|healthy)\b", re.I)
def covered_reason(user_text):
    for sent in re.split(r"(?<=[.!?])\s+", user_text):
        if HEALTH_WEATHER.search(sent) and (not NEGATION.search(sent) or re.search("not feeling well", sent, re.I)): return sent.strip()
    return ""

events = []
for path in sorted(FILES):
    name = os.path.basename(path).replace(".json", ""); data = json.load(open(path, encoding="utf-8"))
    tasks = {str(t["id"]): t for t in data["tasks"]}
    for s in data["simulations"]:
        info = s.get("reward_info") or {}
        if info.get("reward") is None: continue
        msgs = s["messages"]; results = {m.get("id"): m for m in msgs if m["role"] == "tool"}; tid = str(s["task_id"])
        gold = {a["arguments"]["reservation_id"] for a in ((tasks[tid].get("evaluation_criteria") or {}).get("actions") or []) if a["name"] == "cancel_reservation"}
        for i, m in enumerate(msgs):
            if m["role"] != "assistant": continue
            for c in m.get("tool_calls") or []:
                if c["name"] != "cancel_reservation" or (results.get(c["id"]) or {}).get("error"): continue
                state = json.loads(results[c["id"]]["content"]); rid = c["arguments"].get("reservation_id")
                said = " ".join((x.get("content") or "") for x in msgs[:i] if x["role"] == "user")
                g = grade(state); reason = covered_reason(said) if g == "B" else ""
                start = DB["reservations"].get(rid)
                events.append(dict(file=name, holdout=HOLDOUT(name), task=tid, trial=s.get("trial"), rid=rid, msg_index=i, call_id=c["id"],
                                   grade=g, reason_sentence=reason, rule="ineligible" if (g in "CD" or (g == "B" and not reason)) else "eligible",
                                   upgraded=bool(start and state["cabin"] != start["cabin"]), in_gold=rid in gold, native_pass=int(info["reward"] >= 1 - 1e-9),
                                   _sim=s, _state=state))
five = [e for e in events if not e["holdout"]]; hold = [e for e in events if e["holdout"]]
strata = {"F5": [e for e in five if e["rule"] == "ineligible"], "FH": [e for e in hold if e["rule"] == "ineligible"],
          "BC": [e for e in five if e["rule"] == "eligible" and e["grade"] == "B"],
          "AU": [e for e in five if e["grade"] == "A" and e["upgraded"]], "AO": [e for e in five if e["grade"] == "A" and not e["upgraded"]]}
take = {"F5": None, "FH": None, "BC": 15, "AU": 4, "AO": 11}; rng = random.Random(SEED); chosen = []
for k, pool in strata.items():
    pool = sorted(pool, key=lambda e: (e["file"], int(e["task"]), e["trial"], e["msg_index"], e["rid"]))
    pick = pool if take[k] is None else rng.sample(pool, take[k])
    for e in pick: e["stratum"] = k; e["stratum_size"] = len(pool); e["stratum_sampled"] = len(pick)
    chosen += pick
rng.shuffle(chosen)
print("실행된 취소:", {"분석 5개": len(five), "보류 3개": len(hold)}, "| 등급(분석 5개):", dict(sorted(collections.Counter(e["grade"] for e in five).items())))
print("층별 (모집단 -> 표본):", {k: f"{len(v)} -> {len(v) if take[k] is None else take[k]}" for k, v in strata.items()}, "| 문항 수", len(chosen))

def clip(t, n=2500): return t if len(t) <= n else t[:n] + f" …(뒤 {len(t) - n}자 생략)"
def render(e):
    s = e["_sim"]; conv = []; msgs = s["messages"]
    for i, m in enumerate(msgs[: e["msg_index"] + 1]):
        t = (m.get("content") or "").strip()
        if m["role"] == "user" and t: conv.append(dict(role="user", text=t))
        elif m["role"] == "assistant":
            calls = m.get("tool_calls") or []
            if t: conv.append(dict(role="agent", text=t, unseen=bool(calls)))       # 도구 호출과 함께 보낸 글은 사용자에게 가지 않는다
            for c in calls:
                target = (i == e["msg_index"] and c["id"] == e["call_id"])
                conv.append(dict(role="call", text=c["name"] + "(" + json.dumps(c["arguments"], ensure_ascii=False) + ")", target=target))
        elif m["role"] == "tool" and i < e["msg_index"]:
            conv.append(dict(role="result", text=clip(str(m.get("content") or "")), error=bool(m.get("error"))))
    st = e["_state"]; start = DB["reservations"].get(e["rid"]) or {}
    flights = [dict(flight_number=f["flight_number"], origin=f.get("origin"), destination=f.get("destination"), date=f["date"],
                    status=DB["flights"][f["flight_number"]]["dates"].get(f["date"], {}).get("status") or "기록 없음") for f in st["flights"]]
    return dict(reservation=dict(reservation_id=e["rid"], created_at=st["created_at"], cabin=st["cabin"], cabin_at_start=start.get("cabin"),
                                 insurance=st.get("insurance"), passengers=len(st.get("passengers") or []), flights=flights), conversation=conv)
items, key = [], []
for n, e in enumerate(chosen, 1):
    iid = f"K{n:02d}"; items.append(dict(id=iid, **render(e)))
    key.append(dict(id=iid, **{k: v for k, v in e.items() if not k.startswith("_") and k not in ("call_id",)}))
os.makedirs(OUT, exist_ok=True)
items_bytes = json.dumps(items, ensure_ascii=False, indent=1).encode("utf-8"); key_bytes = json.dumps(key, ensure_ascii=False, indent=1).encode("utf-8")
open(os.path.join(OUT, "items.json"), "wb").write(items_bytes)
zi = zipfile.ZipInfo("answer_key.json", date_time=(2026, 11, 22, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED
with zipfile.ZipFile(os.path.join(OUT, "sealed_key.zip"), "w") as z: z.writestr(zi, key_bytes)
policy = open(POLICY_PATH, encoding="utf-8").read(); cancel = policy[policy.index("## Cancel flight"):policy.index("## Refunds and Compensation")].strip()
insurance = policy[policy.index("Travel insurance:"):policy.index("## Modify flight")].strip()      # '보험이 보장하는 사유'를 정하는 유일한 문장
page = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "label_template.html"), encoding="utf-8").read()
page = page.replace("/*ITEMS*/[]", json.dumps(items, ensure_ascii=False).replace("</", "<\\/")).replace("<!--POLICY-->", html.escape(cancel)).replace("<!--INSURANCE-->", html.escape(insurance))
open(os.path.join(OUT, "label.html"), "w", encoding="utf-8").write(page)
manifest = dict(seed=SEED, n_items=len(items), strata={k: dict(population=len(v), sampled=len(v) if take[k] is None else take[k]) for k, v in strata.items()},
                sha256=dict(items_json=hashlib.sha256(items_bytes).hexdigest(), answer_key_json=hashlib.sha256(key_bytes).hexdigest()),
                hidden_from_labeler=["모델 이름", "과제 번호", "공식 판정", "규칙 판정", "정답지 포함 여부"])
json.dump(manifest, open(os.path.join(OUT, "kit_manifest.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("items.json", len(items_bytes) // 1024, "KB | label.html", len(page.encode()) // 1024, "KB | sha256(answer_key.json)", manifest["sha256"]["answer_key_json"][:16], "…")
print("문항당 대화 조각 수 중앙값:", sorted(len(i["conversation"]) for i in items)[len(items) // 2], "| 문항당 글자 수 중앙값:", sorted(sum(len(c["text"]) for c in i["conversation"]) for i in items)[len(items) // 2])

"""맹검 라벨(CSV)을 봉인한 규칙 출력과 대조한다. 표준 라이브러리만 쓴다.

sealed_key.zip의 answer_key.json은 정답이 아니라 규칙이 낸 판정이다. 이 대조는 '규칙이 사람과 같은 판정을 내는가'만 잰다.
규칙과 사람이 갈린 문항에서 어느 쪽이 맞는지는 이 스크립트가 정하지 않는다. 원문을 다시 읽고 disagreements 파일에 직접 적는다.
검증 범위는 취소 자격 판정 하나다. 글이 사용자에게 전달됐는지, 다른 정책 조항을 지켰는지는 이 라벨로 검증되지 않는다.

사용법
  python score_labels.py <키트 폴더> <labels_이름.csv> [<두 번째 라벨러의 csv>]
  python score_labels.py --selftest
출력: 진행 상황, 규칙 판정 × 사람 판정 표, 일치율과 Cohen κ, 층별 일치, 사유 읽기 대조, 모집단 추정, 불일치 목록.
불일치 목록은 <키트 폴더>/disagreements_<이름>.csv로도 저장한다(final_verdict, note 칸은 원문을 다시 읽고 직접 채운다. 이미 채운 칸은 다시 돌려도 지우지 않는다).
규칙 판정: 등급 A, 또는 등급 B이면서 건강·날씨 문장이 잡힘 -> eligible / 등급 C·D, 또는 등급 B인데 그런 문장이 없음 -> ineligible.
"""
import sys, os, csv, json, zipfile, hashlib, collections, statistics
import sys as _sys
if hasattr(_sys.stdout, "reconfigure"): _sys.stdout.reconfigure(encoding="utf-8")

def kappa(pairs):
    """두 판정의 Cohen κ. pairs = [(a, b), ...]"""
    n = len(pairs)
    if not n: return float("nan")
    cats = sorted({x for p in pairs for x in p}); po = sum(a == b for a, b in pairs) / n
    pe = sum((sum(a == c for a, _ in pairs) / n) * (sum(b == c for _, b in pairs) / n) for c in cats)
    return float("nan") if pe == 1 else (po - pe) / (1 - pe)

if len(sys.argv) > 1 and sys.argv[1] == "--selftest":
    t = [("e", "e")] * 20 + [("e", "i")] * 5 + [("i", "e")] * 10 + [("i", "i")] * 15     # 일치율 0.70, 우연 일치 0.50 -> κ 0.40
    assert abs(kappa(t) - 0.4) < 1e-12; assert kappa([("e", "e"), ("i", "i")]) == 1.0
    print("selftest 통과: κ(20,5,10,15) = 0.40"); sys.exit(0)

KIT, MINE = sys.argv[1:3]; OTHER = sys.argv[3] if len(sys.argv) > 3 else None
items = json.load(open(os.path.join(KIT, "items.json"), encoding="utf-8")); manifest = json.load(open(os.path.join(KIT, "kit_manifest.json"), encoding="utf-8"))
key_bytes = zipfile.ZipFile(os.path.join(KIT, "sealed_key.zip")).read("answer_key.json")
assert hashlib.sha256(key_bytes).hexdigest() == manifest["sha256"]["answer_key_json"], "규칙 출력 파일이 키트를 만들 때의 것과 다르다"
assert hashlib.sha256(open(os.path.join(KIT, "items.json"), "rb").read()).hexdigest() == manifest["sha256"]["items_json"], "문항이 키트를 만들 때의 것과 다르다"
key = {k["id"]: k for k in json.loads(key_bytes)}
def read(path):
    rows = list(csv.DictReader(open(path, encoding="utf-8-sig", newline="")))
    return {r["item_id"]: r for r in rows if r.get("item_id") in key and r.get("verdict")}
mine = read(MINE); who = os.path.splitext(os.path.basename(MINE))[0].replace("labels_", "")
secs = [float(r.get("seconds") or 0) for r in mine.values()]
print(f"[진행] 라벨러 {who} | 라벨한 문항 {len(mine)}/{len(items)} | 걸린 시간 합계 {sum(secs)/60:.0f}분, 문항당 중앙값 {statistics.median(secs) if secs else 0:.0f}초")
pairs_all = {(k["task"], k["rid"]) for k in key.values()}; pairs_f5 = {(k["task"], k["rid"]) for k in key.values() if k["stratum"] == "F5"}
print(f"       문항 {len(key)}개는 (과제, 예약) 조합 {len(pairs_all)}가지에서 나왔다. 그중 F5 {sum(k['stratum'] == 'F5' for k in key.values())}문항은 {len(pairs_f5)}가지다. 같은 장면이 여러 번 나온다.")
print(f"       규칙 출력 파일 SHA-256 {manifest['sha256']['answer_key_json'][:16]}… 확인 | 저장 시각 {min((r.get('saved_at') or '') for r in mine.values()) if mine else ''} ~ {max((r.get('saved_at') or '') for r in mine.values()) if mine else ''}")

table = collections.Counter((key[i]["rule"], r["verdict"]) for i, r in mine.items())
print("\n[규칙 판정 × 사람 판정] (행: 규칙, 열: 사람)")
print(f"{'':12s} {'해도 된다':>8s} {'하면 안 된다':>8s} {'판단 불가':>8s}")
for rule, name in (("eligible", "자격 있음"), ("ineligible", "자격 없음")):
    print(f"{name:12s} {table[rule, 'eligible']:10d} {table[rule, 'ineligible']:12d} {table[rule, 'undecidable']:10d}")
decided = [(key[i]["rule"], r["verdict"]) for i, r in mine.items() if r["verdict"] in ("eligible", "ineligible")]
agree = sum(a == b for a, b in decided)
print(f"\n[일치] 사람이 판정을 내린 {len(decided)}문항 중 규칙과 같은 판정 {agree} ({100*agree/max(1,len(decided)):.1f}%) | Cohen κ = {kappa(decided):.2f} | 판단 불가 {sum(r['verdict'] == 'undecidable' for r in mine.values())}")
base = sum(b == "eligible" for _, b in decided) / max(1, len(decided))
print(f"       기준선: 규칙 없이 전부 '해도 된다'로 판정하면 사람 라벨과 {100*base:.1f}% 일치한다. 규칙의 일치율은 이 값과 견주어 읽는다.")
print("       표본은 규칙이 잡은 취소를 전부 넣고 나머지를 일부만 뽑은 것이라, 이 κ는 표본의 값이고 전체 취소의 값이 아니다.")
print("       이 대조가 검증하는 것은 취소 자격 판정 하나다. 전달 여부, 확인 절차, 그 밖의 정책 준수는 검증하지 않는다.")
print("       라벨러가 분석한 사람 본인이면 독립 라벨이 아니다. 두 번째 라벨러의 CSV를 함께 주면 사람 사이 일치도 같이 낸다.")
print("\n[층별 일치] (층: F5 분석 5개에서 규칙이 잡은 것, FH 보류 3개에서 규칙이 잡은 것, BC 보험+사유, AU 등급 변경 뒤 취소, AO 그 밖의 자격 있음)")
for k in ("F5", "FH", "BC", "AU", "AO"):
    v = [(key[i], r) for i, r in mine.items() if key[i]["stratum"] == k]; d = [(x["rule"], r["verdict"]) for x, r in v if r["verdict"] != "undecidable"]
    print(f"   {k}: 표본 {manifest['strata'][k]['sampled']:2d} 중 라벨 {len(v):2d} | 규칙과 같음 {sum(a == b for a, b in d):2d}/{len(d):2d} | 사람이 '하면 안 된다'로 본 것 {sum(r['verdict'] == 'ineligible' for _, r in v)}")
bt = collections.Counter(("문장 잡힘" if key[i]["reason_sentence"] else "문장 없음", r.get("health_weather")) for i, r in mine.items() if key[i]["grade"] == "B")
print("\n[사유 읽기] 등급 B(보험만 있음) 문항에서, 정규식이 건강·날씨 문장을 잡았는가 × 사람이 읽은 답")
for row in ("문장 잡힘", "문장 없음"): print(f"   정규식 {row}: 사람 예 {bt[row, 'yes']}, 아니오 {bt[row, 'no']}, 애매함 {bt[row, 'unclear']}")
est = 0.0; rule_n = 0; complete = True
for k in ("F5", "BC", "AU", "AO"):
    v = [r for i, r in mine.items() if key[i]["stratum"] == k]; N = manifest["strata"][k]["population"]
    if len(v) < manifest["strata"][k]["sampled"]: complete = False
    if v: est += N * sum(r["verdict"] == "ineligible" for r in v) / len(v)
    rule_n += N if k == "F5" else 0
print(f"\n[모집단 추정] 분석 5개의 실행된 취소 {sum(manifest['strata'][k]['population'] for k in ('F5','BC','AU','AO'))}건 중 '하면 안 된다': 규칙 {rule_n}건, 사람 라벨로 추정 {est:.1f}건"
      + ("" if complete else "  (아직 라벨하지 않은 문항이 있어 잠정값)"))
dis = [(i, key[i], r) for i, r in sorted(mine.items()) if r["verdict"] != key[i]["rule"]]
out = os.path.join(KIT, f"disagreements_{who}.csv")
prev = {}
if os.path.exists(out):      # 직접 채운 최종 판정과 메모는 다시 돌려도 남긴다
    with open(out, encoding="utf-8-sig", newline="") as f:
        prev = {row["item_id"]: row for row in csv.DictReader(f)}
done = bool(dis) and all(prev.get(i, {}).get("final_verdict") for i, _, _ in dis)
print(f"\n[불일치·판단 불가 {len(dis)}건] " + ("최종 판정은 disagreements 파일에 적었다" if done else "원문을 다시 읽고 disagreements 파일의 final_verdict, note를 직접 채운다"))
with open(out, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f); w.writerow(["item_id", "stratum", "file", "task", "trial", "reservation", "grade", "rule", "human", "human_grounds", "human_memo", "regex_sentence", "in_gold", "native_pass", "final_verdict", "note"])
    for i, x, r in dis:
        fv, note = prev.get(i, {}).get("final_verdict", ""), prev.get(i, {}).get("note", "")
        print(f"   {i} [{x['stratum']}] {x['file'].split('_sierra')[0]} 과제 {x['task']} t{x['trial']} {x['rid']} 등급 {x['grade']} | 규칙 {x['rule']} / 사람 {r['verdict']} ({r.get('grounds','')}) {('| ' + r['memo']) if r.get('memo') else ''}")
        if fv: print(f"      최종 판정 {fv}: {note}")
        w.writerow([i, x["stratum"], x["file"], x["task"], x["trial"], x["rid"], x["grade"], x["rule"], r["verdict"], r.get("grounds", ""), r.get("memo", ""), x["reason_sentence"], x["in_gold"], x["native_pass"], fv, note])
print("   저장:", out)
if OTHER:
    other = read(OTHER); both = [(mine[i]["verdict"], other[i]["verdict"]) for i in mine if i in other and "undecidable" not in (mine[i]["verdict"], other[i]["verdict"])]
    print(f"\n[두 라벨러] 둘 다 판정한 {len(both)}문항 | 같은 판정 {sum(a == b for a, b in both)} | Cohen κ = {kappa(both):.2f}")

"""라벨링 화면(label.html)만 다시 만든다. 문항(items.json)과 봉인한 규칙 출력(sealed_key.zip)은 건드리지 않는다.

사용법: python rebuild_page.py <policy.md> <키트 폴더>
바뀌는 것: 정책 칸에 Book flight 절의 Travel insurance 원문을 그대로 넣는다(전에는 한국어로 풀어 쓴 한 줄이었다).
확인하는 것: 키트 폴더의 items.json과 sealed_key.zip이 kit_manifest.json에 적힌 SHA-256과 같은지.
"""
import sys, os, json, html, hashlib, zipfile
if hasattr(sys.stdout, "reconfigure"): sys.stdout.reconfigure(encoding="utf-8")
POLICY_PATH, KIT = sys.argv[1:3]
manifest = json.load(open(os.path.join(KIT, "kit_manifest.json"), encoding="utf-8"))
items_bytes = open(os.path.join(KIT, "items.json"), "rb").read()
key_bytes = zipfile.ZipFile(os.path.join(KIT, "sealed_key.zip")).read("answer_key.json")
assert hashlib.sha256(items_bytes).hexdigest() == manifest["sha256"]["items_json"], "문항이 키트를 만들 때의 것과 다르다"
assert hashlib.sha256(key_bytes).hexdigest() == manifest["sha256"]["answer_key_json"], "규칙 출력 파일이 키트를 만들 때의 것과 다르다"
items = json.loads(items_bytes)
policy = open(POLICY_PATH, encoding="utf-8").read()
cancel = policy[policy.index("## Cancel flight"):policy.index("## Refunds and Compensation")].strip()
insurance = policy[policy.index("Travel insurance:"):policy.index("## Modify flight")].strip()
page = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "label_template.html"), encoding="utf-8").read()
page = page.replace("/*ITEMS*/[]", json.dumps(items, ensure_ascii=False).replace("</", "<\\/")).replace("<!--POLICY-->", html.escape(cancel)).replace("<!--INSURANCE-->", html.escape(insurance))
assert "<!--" not in page.split("<main>")[1].split("</main>")[0], "채우지 못한 자리가 남았다"
open(os.path.join(KIT, "label.html"), "w", encoding="utf-8").write(page)
print("label.html", len(page.encode()) // 1024, "KB | 문항", len(items), "| items.json, sealed_key.zip은 그대로 (SHA-256 확인)")
print("넣은 보험 원문:"); print(insurance)

"""전달 판정 읽기 화면(reading.html)과 대조용 키(reading_key.json)를 원자료에서 만든다. LLM은 쓰지 않는다.

사용법: python build_reading.py <결과 파일 8개가 든 폴더 (원본 .json 또는 data/compact의 .json.gz)> <출력 폴더>

대상 10건을 고른 방법 (protocol/judge_vs_rule.py, judge_compare.py의 출력과 같다)
  - 문구 조건이 있는 실행에서 공식 문구 판정(규칙)과 저장된 자연어 단언(LLM)이 갈린 실행 6건 (분석 4, 보류 2)
  - 두 판정은 같지만 요구 문구가 사용자에게 전달된 메시지에 없는 실행 4건 (분석 4)
판정이 의심되는 실행만 모은 표본이다. 두 판정기의 정확도를 추정하는 표본이 아니다.

화면은 모델 이름, 과제 번호, 공식 보상, 두 판정기의 판정을 보여 주지 않는다. 순서는 씨앗 20261123으로 섞는다.
화면이 보여 주는 것: 대화 전체(메시지 번호 포함), 도구 호출이 든 메시지라는 표시, 과제 정의가 요구하는 전달 내용.
"""
import sys, os, json, re, random, html, hashlib
if hasattr(sys.stdout, "reconfigure"): sys.stdout.reconfigure(encoding="utf-8")
D2, OUT = sys.argv[1:3]; os.makedirs(OUT, exist_ok=True)
RUNS = [  # (파일, 과제, 반복, 요구 문구, 한국어 설명)
    ("gpt-5-2_sierra_2026-02-26", "3", 0, ["4"], "상담원이 사용자에게 수하물을 모두 4개 가져갈 수 있다고 알려 준다. (요구하는 수: 4)"),
    ("claude-sonnet-4-5_sierra_2026-02-26", "14", 2, ["1786"], "상담원이 사용자에게 마스터카드로 1,786달러가 결제된다고 알려 준다. (요구하는 수: 1786)"),
    ("claude-sonnet-4-5_sierra_2026-02-26", "14", 3, ["1786"], "상담원이 사용자에게 마스터카드로 1,786달러가 결제된다고 알려 준다. (요구하는 수: 1786)"),
    ("claude-sonnet-4-5_sierra_2026-02-26", "23", 3, ["1286"], "상담원이 사용자에게 마스터카드로 1,286달러가 결제된다고 알려 준다. (요구하는 수: 1286)"),
    ("claude-sonnet-4-5_sierra_2026-02-26", "7", 0, ["1628"], "상담원이 사용자에게 남은 항공편의 총비용이 1,628달러라고 알려 준다. (요구하는 수: 1628)"),
    ("claude-sonnet-4-5_sierra_2026-02-26", "3", 2, ["4"], "상담원이 사용자에게 수하물을 모두 4개 가져갈 수 있다고 알려 준다. (요구하는 수: 4)"),
    ("claude-sonnet-4-5_sierra_2026-02-26", "23", 2, ["327", "1000"], "상담원이 사용자에게 기프트카드 합계 327달러와 증서 합계 1,000달러를 알려 준다. 둘 다 받았을 때만 '예'로 답한다. (요구하는 수: 327, 1000)"),
    ("glm-5-think_sierra_2026-03-02", "14", 0, ["1000"], "상담원이 사용자에게 증서(certificate) 잔액 합계가 1,000달러라고 알려 준다. (요구하는 수: 1000)"),
    ("gpt-5-2-none_sierra_2026-02-26", "3", 1, ["4"], "상담원이 사용자에게 수하물을 모두 4개 가져갈 수 있다고 알려 준다. (요구하는 수: 4)"),
    ("gemini-3-pro_sierra_2026-03-02", "18", 0, ["23553"], "상담원이 사용자에게 모두 23,553달러를 아끼게 된다고 알려 준다. (요구하는 수: 23553)"),
]
has_number = lambda sentence, p: re.search(r"(?<![\w.])" + re.escape(p) + r"(?!\w)", sentence.replace(",", "").replace("$", "")) is not None
cache = {}; items = []; key = []
for n, (fn, task, trial, phrases, need) in enumerate(RUNS, 1):
    if fn not in cache:
        p = os.path.join(D2, fn + ".json")
        cache[fn] = json.load(open(p, encoding="utf-8")) if os.path.exists(p) else json.load(__import__("gzip").open(p + ".gz", "rt", encoding="utf-8"))
    data = cache[fn]; tdef = next(t for t in data["tasks"] if str(t["id"]) == task)
    sim = next(s for s in data["simulations"] if str(s["task_id"]) == task and s.get("trial") == trial)
    asserts = [a for a in ((tdef.get("evaluation_criteria") or {}).get("nl_assertions") or []) if any(has_number(a, p) for p in phrases)]
    assert asserts, (fn, task, phrases)
    conv = []
    for i, m in enumerate(sim["messages"]):
        text = (m.get("content") or "")
        if m["role"] == "user": conv.append(dict(role="user", idx=i, text=text))
        elif m["role"] == "assistant":
            calls = m.get("tool_calls") or []
            if calls: conv.append(dict(role="agent_tool", idx=i, text=text, calls=[c["name"] + "(" + json.dumps(c.get("arguments") or {}, ensure_ascii=False) + ")" for c in calls]))
            else: conv.append(dict(role="agent", idx=i, text=text))
        elif m["role"] == "tool":
            t = text if len(text) <= 4000 else text[:4000] + f"\n…(뒤 {len(text) - 4000}자 생략)"
            conv.append(dict(role="result", idx=i, text=t, error=bool(m.get("error"))))
    info = sim["reward_info"]
    rule = all(c["met"] for c in info.get("communicate_checks") or [] if str(c["info"]) in phrases)
    llm = [bool(x["met"]) for x in (info.get("nl_assertions") or []) if any(has_number(x["nl_assertion"], p) for p in phrases)]
    items.append(dict(need=need, need_en=" / ".join(asserts), conversation=conv))
    key.append(dict(list_no=n, file=fn + ".json", model=fn.split("_sierra")[0], group="보류" if ("gemini" in fn or "none" in fn) else "분석", task=task, trial=trial,
                    phrases=phrases, official_reward=info["reward"], rule_met=rule, llm_met=all(llm) if llm else None))
order = list(range(len(items))); random.Random(20261123).shuffle(order)
page_items = []
for pos, k in enumerate(order, 1):
    rid = f"R{pos:02d}"; page_items.append(dict(id=rid, **items[k])); key[k]["run_id"] = rid
key.sort(key=lambda r: r["run_id"])
tpl = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "reading_template.html"), encoding="utf-8").read()
page = tpl.replace("/*ITEMS*/[]", json.dumps(page_items, ensure_ascii=False).replace("</", "<\\/"))
open(os.path.join(OUT, "reading.html"), "w", encoding="utf-8").write(page)
kb = json.dumps(key, ensure_ascii=False, indent=1).encode("utf-8"); open(os.path.join(OUT, "reading_key.json"), "wb").write(kb)
print("reading.html", len(page.encode()) // 1024, "KB | 실행", len(page_items), "| reading_key.json SHA-256", hashlib.sha256(kb).hexdigest()[:16])
for r in key: print("  ", r["run_id"], "<- 목록", r["list_no"], r["group"], r["model"], "과제", r["task"], "반복", r["trial"], "| 규칙", r["rule_met"], "LLM", r["llm_met"], "보상", r["official_reward"])

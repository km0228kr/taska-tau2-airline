"""읽기 화면에서 내보낸 본인 판정(CSV)을 규칙 판정, 저장된 LLM 단언과 나란히 놓는다. 표준 라이브러리만 쓴다.

사용법: python score_reading.py <kit 폴더> <reading_이름.csv>

규칙 = 공식 문구 판정(부분 문자열). LLM = 결과 파일에 저장된 자연어 단언(이 자료의 보상에는 들어가지 않는다).
본인 = 대화를 끝까지 읽고 '사용자가 그 정보를 받았는가'에 답한 것.
대상 10건은 두 판정기가 갈렸거나 근거가 전달 안 된 글인 실행만 모은 것이다. 여기서 나온 비율은 두 판정기의 일반 정확도가 아니다.
"""
import sys, os, json, csv
if hasattr(sys.stdout, "reconfigure"): sys.stdout.reconfigure(encoding="utf-8")
KIT, CSV_PATH = sys.argv[1:3]
key = {r["run_id"]: r for r in json.load(open(os.path.join(KIT, "reading_key.json"), encoding="utf-8"))}
rows = {r["run_id"]: r for r in csv.DictReader(open(CSV_PATH, encoding="utf-8-sig", newline=""))}
word = {True: "충족", False: "미충족", None: "없음"}; mine = {"yes": "받음", "no": "못 받음", "unclear": "애매함"}
who = next(iter(rows.values()))["labeler"] if rows else "?"
print(f"라벨러 {who} | 읽은 실행 {len(rows)}/{len(key)} | 걸린 시간 합계 {sum(float(r.get('seconds') or 0) for r in rows.values()) / 60:.0f}분")
print(f"\n{'실행':4s} {'묶음':3s} {'모델':20s} {'과제':>3s} {'반복':>3s} {'보상':>4s} | {'규칙':5s} {'LLM':5s} {'본인':6s} | 본인이 적은 값 / 근거")
agree = {"rule": [0, 0], "llm": [0, 0]}; both_wrong = []; split = {"rule": [], "llm": []}; unclear = []
for rid in sorted(key):
    k = key[rid]; r = rows.get(rid)
    if not r: print(f"{rid:4s} {k['group']:3s} {k['model']:20s} {k['task']:>3s} {k['trial']:>3d} {k['official_reward']:>4.1f} | {word[k['rule_met']]:5s} {word[k['llm_met']]:5s} (아직 안 읽음)"); continue
    print(f"{rid:4s} {k['group']:3s} {k['model']:20s} {k['task']:>3s} {k['trial']:>3d} {k['official_reward']:>4.1f} | {word[k['rule_met']]:5s} {word[k['llm_met']]:5s} {mine.get(r['received'], r['received']):6s} | {r['value']} / {r['evidence']}" + (f" / {r['memo']}" if r.get("memo") else ""))
    if r["received"] == "unclear": unclear.append(rid); continue
    h = r["received"] == "yes"
    for name, judged in (("rule", k["rule_met"]), ("llm", k["llm_met"])):
        if judged is None: continue
        agree[name][1] += 1; agree[name][0] += int(judged == h)
    if k["rule_met"] is not None and k["llm_met"] is not None:
        if k["rule_met"] != h and k["llm_met"] != h: both_wrong.append(rid)
        elif k["rule_met"] != k["llm_met"]: split["rule" if k["rule_met"] == h else "llm"].append(rid)
print(f"\n본인 판정과 같은 것: 규칙 {agree['rule'][0]}/{agree['rule'][1]}, LLM 단언 {agree['llm'][0]}/{agree['llm'][1]}" + (f" | 애매함 {len(unclear)}건 {unclear}" if unclear else ""))
print(f"두 판정기가 갈린 실행에서 본인과 같은 쪽: 규칙 {len(split['rule'])}건 {split['rule']}, LLM 단언 {len(split['llm'])}건 {split['llm']}")
print(f"두 판정기가 같은데 본인과 다른 실행(같이 틀린 것): {len(both_wrong)}건 {both_wrong}")
passed_not_received = [rid for rid in sorted(rows) if rows[rid]["received"] == "no" and key[rid]["official_reward"] >= 1]
print(f"공식 통과인데 본인 판정으로는 사용자가 정보를 받지 못한 실행: {len(passed_not_received)}건 {passed_not_received}")
print("\n이 10건은 판정이 의심되는 실행만 모은 것이다. 위 비율을 두 판정기의 정확도로 쓰지 않는다. 라벨러는 분석한 사람 본인 한 명이다.")

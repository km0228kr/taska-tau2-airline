# 검증 자료 (노트북 5-3)

| 폴더 | 무엇을 검증하나 | 누가 판정했나 |
|---|---|---|
| `replay/` | 저장된 DB 판정과 도구 오류 기록이 실제 도구 실행과 같은가 | 저장소의 airline 도구 코드 |
| `sealed_predictions/` | 분석 결과가 보지 않은 파일 3개에도 맞는가 | 예측을 먼저 적고 해시를 남긴 뒤 계산 |
| `delivery_reading/` | 문구 판정이 통과시킨 정보를 사용자가 실제로 받았는가 | 사람(판독자 1명, 분석한 본인) |
| `cancel_blind_labels/` | 취소 자격(등급과 건강·날씨 사유)을 규칙이 옳게 판정했는가 | 사람(라벨러 1명, 분석한 본인). 59문항 중 58문항이 규칙과 같음 |
| `case_reading/` | 5-2 사례 6건과 막힌 쓰기 10건(실행 6개)의 원인 구분 | 사람(본인, AI 초안을 본 뒤 다시 읽음). 판독 화면에는 초안의 판단을 넣지 않았다 |
| `tau2_source/` | 노트북이 인용한 프레임워크 코드 | 원본 그대로 |

## delivery_reading

- `reading.html`: 판독 화면. 브라우저로 연다. 모델 이름, 과제 번호, 기존 판정을 가렸다. 도구 호출 메시지는 점선 상자로 표시한다.
- `reading_key.json`: 화면의 R01~R10이 어느 실행인지와 두 판정기(규칙, 저장된 LLM 단언)의 판정.
- `reading_first_answer.csv`: 첫 답. `reading_kkm.csv`: 최종 답. R02 하나만 바뀌었다(근거로 적은 [10]이 도구 호출 메시지라는 지적을 받고 다시 확인함).
- `build_reading.py`, `reading_template.html`: 화면을 원자료에서 다시 만든다. `score_reading.py`: 판독을 두 판정기와 대조한다.
- 10건은 판정이 의심되는 실행만 고른 것이다. 판정기의 정확도를 추정하는 표본이 아니다.

## cancel_blind_labels

- `label.html`: 판독 화면. 답은 브라우저에 저장되고 CSV로 내보낸다. 내보낸 CSV를 `labels_<이름>.csv`로 이 폴더에 두면 노트북 5-3 ⑤ 셀이 자동으로 채점한다.
- `items.json`: 59문항. `sealed_key.zip`: 규칙이 각 문항에 낸 판정(정답이 아니라 대조 기준). 두 파일의 SHA-256은 `kit_manifest.json`에 있다.
- `score_labels.py`: 사람 라벨과 규칙 판정을 대조한다. `build_kit.py`는 원본 결과 파일(.json)로 문항을 만든 스크립트, `rebuild_page.py`는 화면만 다시 만든다.
- `labels_kkm.csv`: 본인 라벨 59문항. `disagreements_kkm.csv`: 규칙과 갈린 문항(K56 하나)과 최종 판정. K56은 사람 라벨이 맞고 규칙의 부정어 필터가 틀렸다(노트북 5-3 ⑤).
- 이 라벨이 검증하는 것은 취소 자격 하나다.

## sealed_predictions

- `predictions.json`: 사전 예측 6개(SHA-256 5ec9c193…). 해시는 내용이 바뀌지 않았다는 것만 보인다. 적은 시각을 증명하지는 못한다.
- `holdout_eval.py`, `holdout_result.txt`: 재생 결과로 예측을 확인한 스크립트와 그 출력.

## replay

`README.md` 참고.

"""봉인한 예측 P1~P6을 보류 파일 3개의 재채점 결과(json)로 판정한다.

사용법: python holdout_eval.py <regrade.py가 만든 json> <db.json> <predictions.json>
"""
import json, sys, collections, hashlib
import sys as _sys
if hasattr(_sys.stdout, "reconfigure"): _sys.stdout.reconfigure(encoding="utf-8")
from datetime import datetime, timedelta
rows = json.load(open(sys.argv[1], encoding="utf-8")); DB = json.load(open(sys.argv[2], encoding="utf-8")); NOW = datetime(2024, 5, 15, 15, 0, 0)
print("predictions.json SHA-256:", hashlib.sha256(open(sys.argv[3], "rb").read()).hexdigest())
def grade(res):
    st = [DB["flights"][f["flight_number"]]["dates"].get(f["date"], {}).get("status") for f in res["flights"]]
    if any(s in ("landed", "flying") for s in st) or any(f["date"] < "2024-05-15" and s != "cancelled" for f, s in zip(res["flights"], st)): return "D"
    if NOW - datetime.fromisoformat(res["created_at"]) <= timedelta(hours=24) or res["cabin"] == "business" or any(s == "cancelled" for s in st): return "A"
    return "B" if res.get("insurance") == "yes" else "C"
files = sorted({r["file"] for r in rows}); by = {f: [r for r in rows if r["file"] == f] for f in files}
flash = [f for f in files if "flash" in f][0]; pro = [f for f in files if "pro" in f][0]; med = [f for f in files if "none" in f][0]
ok_cancels = lambda r: [c for c in r["cancels"] if c["ok"]]
print("\n[P1] 저장된 DB 판정 == 재생:", {f: f"{sum(bool(r['stored_db']) == bool(r['db_embedded']) for r in v)}/{len(v)}" for f, v in by.items()},
      "| 저장 보상 == DB x 문구:", {f: f"{sum(r['native'] == r['db_embedded'] * r['comm_embedded'] for r in v)}/{len(v)}" for f, v in by.items()})
for f, v in by.items():
    new = [r["db_current"] * r["comm_current"] for r in v]
    print(f"[재채점] {f}: 저장 보상 통과 {sum(r['native'] for r in v)}/{len(v)} -> 현행 정답 기준 통과 {sum(new)}/{len(v)} | 바뀐 판정 {sum(n != r['native'] for n, r in zip(new, v))} (실패→통과 {sum(r['native'] == 0 and n == 1 for n, r in zip(new, v))}, 통과→실패 {sum(r['native'] == 1 and n == 0 for n, r in zip(new, v))})")
v = by[flash]; new = sum(r["db_current"] * r["comm_current"] for r in v)
print(f"\n[P2] Gemini 3 Flash 현행 정답 재채점: {new}/200 = {new/2:.1f}% (예측 165/200 = 82.5%) ->", "적중" if new == 165 else "빗나감")
t = [r for r in v if r["task"] in ("9", "37")]; not_cancelled = [r for r in t if "NQNU5R" not in [c["rid"] for c in ok_cancels(r)]]
print(f"[P3] Gemini 3 Flash 과제 9·37: {len(t)}회 중 NQNU5R을 취소하지 않은 실행 {len(not_cancelled)}회 (예측 5회 이상) ->", "적중" if len(not_cancelled) >= 5 else "빗나감",
      "| 그 실행의 저장 보상 통과", sum(r["native"] for r in not_cancelled), "| 현행 정답 기준 통과", sum(r["db_current"] * r["comm_current"] for r in not_cancelled))
t39 = [r for r in by[med] if r["task"] == "39"]; two = [r for r in t39 if sorted(c["rid"] for c in ok_cancels(r)) == ["8C8K4E", "LU15PA"]]
print(f"[P4] GPT-5.2 medium 과제 39: {len(t39)}회 중 business 두 건만 취소 {len(two)}회, 그중 공식 실패 {sum(r['native'] == 0 for r in two)}회 (예측 2회 이상) ->", "적중" if sum(r["native"] == 0 for r in two) >= 2 else "빗나감",
      "| 세 건 모두 취소:", sum(sorted(c["rid"] for c in ok_cancels(r)) == ["8C8K4E", "LU15PA", "MSJ4OA"] for r in t39))
p5 = {}
for f in (med, pro):
    ev = [(r, c) for r in by[f] for c in ok_cancels(r) if c["before"] is not None]; g = collections.Counter(grade(c["before"]) for r, c in ev)
    bad = [(r["task"], c["rid"], grade(c["before"]), r["native"]) for r, c in ev if grade(c["before"]) in "CD" and c["rid"] not in r["gold_cancels_embedded"]]
    p5[f] = (len(bad), len(ev)); print(f"[P5] {f}: 실행된 취소 {len(ev)}건, 등급 {dict(sorted(g.items()))}, 정답에 없는 C·D {len(bad)}건 = {100*len(bad)/max(1,len(ev)):.1f}% {bad}")
print("     ->", "적중" if all(b / max(1, n) <= 0.05 for b, n in p5.values()) else "빗나감")
out = [(r["file"], r["task"], c["rid"]) for r in rows if r["native"] == 1 for c in ok_cancels(r) if c["rid"] not in r["gold_cancels_embedded"]]
print(f"[P6] 통과한 실행에서 정답 밖의 취소: {len(out)}건 (예측 0건) ->", "적중" if not out else "빗나감", out[:5])
ev = [(r, c) for r in v for c in ok_cancels(r) if c["before"] is not None]
flag = [(r["task"], c["rid"], grade(c["before"]), r["native"], c["rid"] in r["gold_cancels_embedded"]) for r, c in ev if grade(c["before"]) in "CD"]
print(f"\n[참고] Gemini 3 Flash(옛 정답): 실행된 취소 {len(ev)}건, C·D {len(flag)}건 | 그중 통과한 실행 안의 것 {sum(x[3] for x in flag)}건 {sorted(set((x[0], x[1], x[2]) for x in flag if x[3]))} | 정답에 없는 C·D {sum(not x[4] for x in flag)}건")

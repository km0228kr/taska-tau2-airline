"""본인이 직접 판독할 화면(case_reading.html)을 만든다.

문항: 5-2의 사례 6개(A1~A6), 다시 성공하지 못한 막힌 쓰기가 있는 실행 6개(B1~B6, 표 5-7의 10건),
취소 라벨 K56의 규칙 오류(C1), 본인이 한 일 확인(D, 선택).
화면에는 노트북에 적힌 AI 초안의 원인 판단을 넣지 않는다. 궤적 원문, 과제 지시, 정답 행동, 요구 문구, 공식 판정만 보여 준다.

실행: python3 validation/case_reading/build_case_kit.py   (제출 폴더 최상위에서)
"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, ROOT)
import taska_harness as H  # noqa: E402

SHORT = {"claude-opus-4-5": "Opus 4.5", "gpt-5-2": "GPT-5.2", "glm-5-think": "GLM-5", "qwen3.5-397b-a17b-think": "Qwen3.5",
         "claude-sonnet-4-5": "Sonnet 4.5", "gemini-3-flash": "Gemini 3 Flash"}

os.chdir(ROOT)
runs, meta = H.load("data/compact")
db = H.read_json("data/airline/db.json.gz")
policy = open("data/airline/policy.md", encoding="utf-8").read()
A = [r for r in runs if r.group == "분석"]


def pick(model, task, trial, group="분석"):
    return next(r for r in runs if r.model == model and r.task == task and r.trial == trial and r.group == group)


def messages(run):
    out = []
    for i, m in enumerate(run.messages):
        item = {"i": i, "role": m["role"], "text": H.text_of(m) or ""}
        if m["role"] == "assistant" and m.get("tool_calls"):
            item["calls"] = [{"name": c["name"], "args": c["arguments"]} for c in m["tool_calls"]]
        if m["role"] == "tool":
            item["text"] = str(m.get("content") or "")
            item["error"] = bool(m.get("error"))
        out.append(item)
    return out


def context(run):
    crit = run.task_def.get("evaluation_criteria") or {}
    return {"model": SHORT.get(run.model, run.model), "task": run.task, "trial": run.trial,
            "official": "통과" if run.passed else "실패",
            "instructions": (run.task_def.get("user_scenario") or {}).get("instructions") or {},
            "gold": [{"name": a["name"], "args": a.get("arguments") or {}} for a in crit.get("actions") or []],
            "phrases": list(crit.get("communicate_info") or [])}


def section(md, title):
    m = re.search(rf"^## {re.escape(title)}\n(.*?)(?=^## |\Z)", md, re.S | re.M)
    return m.group(1).strip()


items = []
cases = [("A1", "사례 1", "gpt-5-2", "3", 0), ("A2", "사례 2", "claude-sonnet-4-5", "3", 2), ("A3", "사례 3", "glm-5-think", "14", 0),
         ("A5", "사례 5", "claude-opus-4-5", "34", 0), ("A6", "사례 6", "claude-sonnet-4-5", "7", 0)]
for iid, title, model, task, trial in cases:
    r = pick(model, task, trial)
    items.append({"id": iid, "kind": "case", "title": f"{title} · {SHORT[model]} 과제 {task} 반복 {trial}", **context(r), "messages": messages(r)})

# 사례 4: 과제 39 (20회). 정책 원문, 예약 사실, 20회의 결과, 정책대로 남긴 실행 하나의 원문
t39 = [r for r in A if r.task == "39"]
gold_cancels = [a["arguments"]["reservation_id"] for a in t39[0].task_def["evaluation_criteria"]["actions"] if a["name"] == "cancel_reservation"]
reservations = []
for rid in gold_cancels:
    res = db["reservations"][rid]
    reservations.append({"reservation_id": rid, "cabin": res["cabin"], "insurance": res["insurance"], "created_at": res["created_at"],
                         "flights": [{"flight_number": f["flight_number"], "date": f["date"],
                                      "status": db["flights"][f["flight_number"]]["dates"].get(f["date"], {}).get("status")} for f in res["flights"]]})
cancelled = lambda r: sorted(c.args.get("reservation_id") for c in r.calls if c.name == "cancel_reservation" and not c.error)
order = ["claude-opus-4-5", "gpt-5-2", "glm-5-think", "qwen3.5-397b-a17b-think", "claude-sonnet-4-5"]
table39 = [{"model": SHORT[r.model], "trial": r.trial, "cancelled": cancelled(r), "official": "통과" if r.passed else "실패"}
           for r in sorted(t39, key=lambda r: (order.index(r.model), r.trial))]
kept = next(r for r in sorted(t39, key=lambda r: (order.index(r.model), r.trial)) if "MSJ4OA" not in cancelled(r))
items.append({"id": "A4", "kind": "task39", "title": "사례 4 · 과제 39 (모델 5개 × 4회)", **context(kept),
              "policy_now": "The current time is 2024-05-15 15:00:00 EST.", "policy_cancel": "## Cancel flight\n" + section(policy, "Cancel flight"),
              "reservations": reservations, "runs39": table39,
              "example": f"정책대로 MSJ4OA를 남긴 실행 하나의 원문: {SHORT[kept.model]} 반복 {kept.trial}", "messages": messages(kept)})

# 표 5-7: 다시 성공하지 못한 막힌 쓰기가 있는 실행 (호출 10건, 실행 6개)
blocked = {}
for r in A:
    for c in r.calls:
        if not (c.is_write and c.error):
            continue
        rid = c.args.get("reservation_id")
        if any(d.index > c.index and d.name == c.name and d.args.get("reservation_id") == rid and not d.error for d in r.calls):
            continue
        blocked.setdefault((r.model, r.task, r.trial), []).append({"i": c.index, "name": c.name, "args": c.args, "error": c.result[:300]})
for n, ((model, task, trial), calls) in enumerate(blocked.items(), 1):
    r = pick(model, task, trial)
    same = " (사례 5와 같은 실행)" if (model, task, trial) == ("claude-opus-4-5", "34", 0) else ""
    items.append({"id": f"B{n}", "kind": "blocked", "title": f"막힌 쓰기 {n} · {SHORT[model]} 과제 {task} 반복 {trial}{same}",
                  **context(r), "blocked": calls, "messages": messages(r)})

# K56: 취소 라벨에서 규칙과 갈린 문항
r56 = pick("gemini-3-flash", "19", 2, group="보류")
rule = H.CancelRule(db)
import inspect  # noqa: E402
said = " ".join(H.text_of(m) for m in r56.messages if m["role"] == "user")
sentences = [s for s in re.split(r"(?<=[.!?])\s+", said) if rule.HEALTH_WEATHER.search(s)]
items.append({"id": "C1", "kind": "k56", "title": "K56 · 규칙과 내 라벨이 갈린 문항", **context(r56),
              "policy_cancel": "## Cancel flight\n" + section(policy, "Cancel flight"), "sentences": sentences,
              "health_weather": rule.HEALTH_WEATHER.pattern, "negation": rule.NEGATION.pattern,
              "code": inspect.getsource(H.CancelRule.covered_reason), "messages": messages(r56)})

items.append({"id": "D", "kind": "self", "title": "내가 한 일 확인 (선택)"})

items.sort(key=lambda x: (x["id"][0], int(x["id"][1:] or 0)))
kit = {"kit": "case_reading_v1", "items": items}
with open(os.path.join(HERE, "items.json"), "w", encoding="utf-8") as f:
    json.dump(kit, f, ensure_ascii=False, indent=1)
template = open(os.path.join(HERE, "case_template.html"), encoding="utf-8").read()
payload = json.dumps(kit, ensure_ascii=False).replace("</", "<\\/")
with open(os.path.join(HERE, "case_reading.html"), "w", encoding="utf-8") as f:
    f.write(template.replace("__KIT_JSON__", payload))
print("문항", len(items), "| 막힌 쓰기 호출", sum(len(v) for v in blocked.values()), "건, 실행", len(blocked), "개")
print("크기", os.path.getsize(os.path.join(HERE, "case_reading.html")) // 1024, "KB")

"""벤치마크의 실제 airline 도구 코드로 궤적과 정답을 다시 재생해 DB 판정을 독립적으로 확인한다.

사용법
  tau2를 설치한 환경:  python replay_check.py installed <tau2 data 폴더> <결과 glob> <출력 json> [five]
  설치 없이(README 참고): python replay_check.py <shadow와 stubs가 든 폴더> <tau2 data 폴더> <결과 glob> <출력 json> [five]
공식 DB 판정과 같은 절차다: 새 DB에 에이전트의 쓰기 호출을 순서대로 다시 실행하고, 다른 새 DB에 정답 행동을 실행한 뒤 두 DB의 해시를 비교한다.
도구 코드(AirlineTools, FlightDB, 해시)는 저장소의 것을 그대로 쓴다. LLM 호출은 없다.
"""
import sys, os, json, glob, time, collections
def _open(p): return __import__("gzip").open(p, "rt", encoding="utf-8") if p.endswith(".gz") else open(p, encoding="utf-8")
R, DATA, PATTERN, OUT = sys.argv[1:5]; ONLY_FIVE = len(sys.argv) > 5
if R != "installed": sys.path.insert(0, R + "/stubs"); sys.path.insert(0, R + "/shadow")
os.environ["TAU2_DATA_DIR"] = DATA
from tau2.domains.airline.data_model import FlightDB
from tau2.domains.airline.tools import AirlineTools

BASE = FlightDB.load(DATA + "/tau2/domains/airline/db.json"); BASE_HASH = BASE.get_hash()
MUTATING = {n for n in AirlineTools(BASE).tools if getattr(getattr(AirlineTools, n), "__mutates_state__", False)}

def run(calls, watch_cancel=False):
    """새 DB 사본에 호출을 순서대로 실행한다. (해시, 호출별 오류 여부, 취소 직전 예약 상태)를 돌려준다."""
    if not calls: return BASE_HASH, [], []
    tools = AirlineTools(BASE.model_copy(deep=True)); errors = []; before = []
    for name, args in calls:
        state = None
        if watch_cancel and name == "cancel_reservation":
            r = tools.db.reservations.get(args.get("reservation_id"))
            state = json.loads(r.model_dump_json()) if r is not None else None
        try: tools.use_tool(name, **args); errors.append(False)
        except Exception: errors.append(True)
        before.append(state)
    return tools.db.get_hash(), errors, before

rows = []; t0 = time.time()
for path in sorted(glob.glob(PATTERN)):
    name = os.path.basename(path)
    if ONLY_FIVE and ("gemini" in name or "none" in name): continue
    data = json.load(_open(path)); model = name.split("_sierra")[0].split("_airline")[0]
    tasks = {str(t["id"]): t for t in data["tasks"]}; gold_hash = {}; variants = {}
    for tid, t in tasks.items():
        acts = [(a["name"], a["arguments"]) for a in ((t.get("evaluation_criteria") or {}).get("actions") or []) if a["name"] in MUTATING]
        gold_hash[tid] = run(acts)[0]
        if tid == "39": variants["39_no_MSJ4OA"] = run([a for a in acts if not (a[0] == "cancel_reservation" and a[1].get("reservation_id") == "MSJ4OA")])[0]
        if tid == "44": variants["44_no_KC18K6"] = run([a for a in acts if a[1].get("reservation_id") != "KC18K6"])[0]
    for s in data["simulations"]:
        info = s.get("reward_info") or {}
        if info.get("reward") is None: continue
        tid = str(s["task_id"]); msgs = s["messages"]; results = {m.get("id"): m for m in msgs if m["role"] == "tool"}
        calls = []; recorded_err = []
        for m in msgs:
            if m["role"] != "assistant": continue
            for c in m.get("tool_calls") or []:
                if c["name"] in MUTATING:
                    calls.append((c["name"], c["arguments"])); recorded_err.append(bool((results.get(c["id"]) or {}).get("error")))
        h, errs, before = run(calls, watch_cancel=True)
        stored = (info.get("db_check") or {}).get("db_match")
        rows.append(dict(model=model, task=tid, trial=s.get("trial"), passed=int(info["reward"] >= 1 - 1e-9), stored_db=stored,
                         replay_db=(h == gold_hash[tid]), n_calls=len(calls), err_mismatch=sum(a != b for a, b in zip(errs, recorded_err)),
                         v39=(h == variants["39_no_MSJ4OA"]) if tid == "39" and "39_no_MSJ4OA" in variants else None,
                         v44=(h == variants["44_no_KC18K6"]) if tid == "44" and "44_no_KC18K6" in variants else None,
                         cancels=[dict(rid=a.get("reservation_id"), err=e, before=b) for (n, a), e, b in zip(calls, errs, before) if n == "cancel_reservation"]))
    print(f"{model}: {sum(r['model']==model for r in rows)}건 재생, 누적 {time.time()-t0:.0f}초", flush=True)
json.dump(rows, open(OUT, "w"), ensure_ascii=False)
have = [r for r in rows if r["stored_db"] is not None]
print(f"\n재생 {len(rows)}건 | 저장된 DB 판정이 있는 {len(have)}건 중 재생 결과와 같은 것 {sum(bool(r['stored_db']) == r['replay_db'] for r in have)}")
print("오류 여부가 기록과 다른 쓰기 호출이 있는 대화:", sum(r["err_mismatch"] > 0 for r in rows), "| 쓰기 호출 합계:", sum(r["n_calls"] for r in rows))
bad = [r for r in have if bool(r["stored_db"]) != r["replay_db"]]
for r in bad[:20]: print("   불일치:", r["model"], "과제", r["task"], "trial", r["trial"], "저장", r["stored_db"], "재생", r["replay_db"], "통과", r["passed"])

# 실제 airline 도구로 재생

저장소의 airline 도구 코드(AirlineTools, FlightDB)로 궤적의 쓰기 호출을 새 DB에 순서대로 다시 실행하고, 정답 행동을 실행한 DB와 해시를 비교한다. 공식 DB 판정과 같은 절차다. LLM 호출은 없다.

- `d2_replay.json`: 분석 5개, 1,000건. 저장된 DB 판정과 재생 결과가 1,000건 모두 같다.
- `holdout_regrade.json`: 보류 3개, 597건. 파일에 든 정답과 현행 정답 두 기준으로 다시 채점한 결과.

## 다시 돌리기

필요한 것: Python 3.10 이상, pydantic, python-dotenv, PyYAML, tau2-bench 저장소.

```
git clone https://github.com/sierra-research/tau2-bench
cd tau2-bench && git checkout 768f3d8fe8528b4f32a5096f9ed008ae50f48ead && cd ..

python validation/replay/make_shadow.py tau2-bench /tmp/shadow
python validation/replay/replay_check.py /tmp/shadow tau2-bench/data "data/compact/*.json.gz" out_d2.json five
python validation/replay/regrade.py /tmp/shadow tau2-bench/data data/airline/tasks.json out_holdout.json \
    data/compact/gemini-3-flash_sierra_2026-03-02.json.gz data/compact/gemini-3-pro_sierra_2026-03-02.json.gz data/compact/gpt-5-2-none_sierra_2026-02-26.json.gz
```

`make_shadow.py`는 airline 도구를 돌리는 데 필요한 저장소 파일 13개만 복사하고, 모델 호출 패키지 대신 `stubs/`의 대역을 쓴다. tau2를 설치한 환경이면 첫 인자로 `installed`를 준다. 분석 5개는 약 2분, 보류 3개는 약 1분 반 걸린다.

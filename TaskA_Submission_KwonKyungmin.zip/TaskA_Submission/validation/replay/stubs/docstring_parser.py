"""설치되지 않은 docstring 파서의 대역. 도구 설명 생성에만 쓰이고 도구 실행에는 쓰이지 않는다."""
class _Doc:
    short_description = ""; long_description = ""; params = []; returns = None; raises = []; examples = []
def parse(text):
    return _Doc()

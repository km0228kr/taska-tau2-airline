"""설치되지 않은 로깅 라이브러리의 대역. 아무 일도 하지 않는다."""
class _Logger:
    def __getattr__(self, name):
        return lambda *a, **k: None
logger = _Logger()

"""설치되지 않은 addict의 대역. 재생에서는 호출하지 않는다."""
class Dict(dict):
    def to_dict(self): return dict(self)

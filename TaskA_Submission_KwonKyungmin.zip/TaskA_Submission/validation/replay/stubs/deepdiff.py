"""설치되지 않은 비교 라이브러리의 대역. 재생에서는 호출하지 않는다."""
class DeepDiff(dict):
    def __init__(self, *a, **k): super().__init__()

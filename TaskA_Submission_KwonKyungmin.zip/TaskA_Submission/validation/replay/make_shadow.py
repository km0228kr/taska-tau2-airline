"""tau2-bench 소스에서 airline 도구를 돌리는 데 필요한 파일 13개만 복사해 재생용 폴더를 만든다.

사용법: python make_shadow.py <tau2-bench 소스 폴더 (그 아래 src/tau2가 있어야 한다)> <만들 폴더>
만든 폴더에는 shadow/(복사한 tau2 모듈, 패키지의 __init__.py는 빈 파일)와 stubs/(loguru, docstring_parser, deepdiff, addict 대역)가 생긴다.
필요한 패키지: pydantic, python-dotenv, PyYAML. 모델 호출 패키지는 필요 없다.
"""
import os, shutil, sys
SRC, OUT = sys.argv[1:3]; S = os.path.join(SRC, "src", "tau2"); HERE = os.path.dirname(os.path.abspath(__file__))
FILES = ["domains/airline/data_model.py", "domains/airline/tools.py", "domains/airline/region.py", "domains/airline/utils.py",
         "environment/db.py", "environment/tool.py", "environment/toolkit.py", "environment/regional.py",
         "utils/__init__.py", "utils/io_utils.py", "utils/pydantic_utils.py", "utils/utils.py", "utils/text_match.py"]
for f in FILES:
    dst = os.path.join(OUT, "shadow", "tau2", f); os.makedirs(os.path.dirname(dst), exist_ok=True); shutil.copyfile(os.path.join(S, f), dst)
for d in ("", "domains", "domains/airline", "environment"):
    open(os.path.join(OUT, "shadow", "tau2", d, "__init__.py"), "w").close()
os.makedirs(os.path.join(OUT, "stubs"), exist_ok=True)
for f in os.listdir(os.path.join(HERE, "stubs")):
    if f.endswith(".py"): shutil.copyfile(os.path.join(HERE, "stubs", f), os.path.join(OUT, "stubs", f))
print("재생용 폴더:", OUT, "| 복사한 tau2 파일", len(FILES))

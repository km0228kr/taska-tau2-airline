"""저장된 궤적을 (1) 파일에 든 정답과 (2) 현행 정답 두 기준으로 실제 airline 도구에 재생해 다시 채점한다.

사용법: python regrade.py <shadow와 stubs가 든 폴더 또는 installed> <tau2 data 폴더> <현행 tasks.json> <출력 json> <결과 파일 또는 폴더...>
DB 항: 에이전트의 쓰기 호출을 새 DB에 재생한 해시 == 정답 행동을 재생한 해시.
문구 항: communicate_info의 각 문자열이 어느 한 에이전트 발화에 들어 있는가(소문자, 쉼표 제거). 공식 substring 규칙과 같다.
"""
import sys, os, json
import sys as _sys
if hasattr(_sys.stdout, "reconfigure"): _sys.stdout.reconfigure(encoding="utf-8")
import glob as _glob
def _expand(args): return [f for a in args for f in (sorted(_glob.glob(os.path.join(a, '*.json')) + _glob.glob(os.path.join(a, '*.json.gz'))) if os.path.isdir(a) else sorted(_glob.glob(a)) or [a]) if 'manifest' not in f]
def _open(p): return __import__("gzip").open(p, "rt", encoding="utf-8") if p.endswith(".gz") else open(p, encoding="utf-8")
R, DATA, CUR_TASKS, OUT = sys.argv[1:5]; FILES = _expand(sys.argv[5:])
if R != "installed": sys.path.insert(0, R + "/stubs"); sys.path.insert(0, R + "/shadow")
os.environ["TAU2_DATA_DIR"] = DATA
from tau2.domains.airline.data_model import FlightDB
from tau2.domains.airline.tools import AirlineTools
BASE = FlightDB.load(DATA + "/tau2/domains/airline/db.json"); H0 = BASE.get_hash()
MUT = {n for n in AirlineTools(BASE).tools if getattr(getattr(AirlineTools, n), "__mutates_state__", False)}

def replay(calls, watch=False):
    if not calls: return H0, []
    tools = AirlineTools(BASE.model_copy(deep=True)); before = []
    for name, args in calls:
        state = None
        if watch and name == "cancel_reservation":
            r = tools.db.reservations.get(args.get("reservation_id")); state = json.loads(r.model_dump_json()) if r is not None else None
        try: tools.use_tool(name, **args); ok = True
        except Exception: ok = False
        before.append((ok, state))
    return tools.db.get_hash(), before

def gold_of(task):
    ec = task.get("evaluation_criteria") or {}
    return [(a["name"], a["arguments"]) for a in (ec.get("actions") or []) if a["name"] in MUT], list(ec.get("communicate_info") or [])

def communicated(infos, msgs):
    texts = [(m.get("content") or "").lower().replace(",", "") for m in msgs if m["role"] == "assistant" and (m.get("content") or "").strip()]
    return int(all(any(str(i).lower() in t for t in texts) for i in infos))

current = {str(t["id"]): gold_of(t) for t in json.load(open(CUR_TASKS, encoding="utf-8"))}
cur_hash = {tid: replay(g[0])[0] for tid, g in current.items()}
rows = []
for path in FILES:
    data = json.load(_open(path)); name = os.path.basename(path).replace(".json.gz", "").replace(".json", "")
    emb = {str(t["id"]): gold_of(t) for t in data["tasks"]}; emb_hash = {tid: replay(g[0])[0] for tid, g in emb.items()}
    same_gold = sum(emb_hash[t] == cur_hash[t] and emb[t][1] == current[t][1] for t in emb)
    n = 0
    for s in data["simulations"]:
        info = s.get("reward_info") or {}
        if info.get("reward") is None: continue
        tid = str(s["task_id"]); msgs = s.get("messages") or []
        calls = [(c["name"], c["arguments"]) for m in msgs if m["role"] == "assistant" for c in (m.get("tool_calls") or []) if c["name"] in MUT]
        h, before = replay(calls, watch=True)
        cancels = [dict(rid=a.get("reservation_id"), ok=ok, before=st) for (nm, a), (ok, st) in zip(calls, before) if nm == "cancel_reservation"]
        rows.append(dict(file=name, task=tid, trial=s.get("trial"), native=int(info["reward"] >= 1 - 1e-9),
                         stored_db=(info.get("db_check") or {}).get("db_match"), db_embedded=int(h == emb_hash[tid]),
                         comm_embedded=communicated(emb[tid][1], msgs), db_current=int(h == cur_hash[tid]), comm_current=communicated(current[tid][1], msgs),
                         gold_cancels_embedded=[a.get("reservation_id") for nm, a in emb[tid][0] if nm == "cancel_reservation"], cancels=cancels))
        n += 1
    print(f"{name}: 실행 {len(data['simulations'])}건 중 보상 있는 {n}건 재생 | 파일에 든 정답이 현행 정답과 같은 과제 {same_gold}/50", flush=True)
json.dump(rows, open(OUT, "w", encoding="utf-8"), ensure_ascii=False)

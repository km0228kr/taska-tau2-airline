# Task A 제출물: τ²-bench airline 궤적 분석 (권경민)

## 보는 순서

1. `TaskA_Agent.ipynb`: 본문. 코드와 결과가 모두 노트북 안에 있고, 실행 출력도 저장돼 있다. 표준 라이브러리만 쓰고 1분 안팎이 걸린다.
   - Colab: 노트북만 열고 Run all을 누른다. 첫 실행 셀이 공개 저장소(github.com/km0228kr/taska-tau2-airline)에서 이 zip을 받아 풀고 그 폴더로 옮겨 간다.
   - 로컬 Jupyter: zip을 푼 이 폴더에서 열고 Restart & Run All을 누른다.
   - 분석 하네스(`taska_harness.py`)는 노트북의 셀이 파일로 쓴다. 폴더의 같은 파일은 그 셀과 내용이 같다.
2. `data_sources.json`: 궤적 파일의 URL, SHA-256, tau2 버전, 수집 일자, 분석에서 뺀 파일과 이유.
3. `validation/`: 5-3 검증에 쓴 판정 결과, 라벨, 스크립트.

## 폴더

| 경로 | 내용 |
|---|---|
| `taska_harness.py` | 분석 하네스. 문제 유형 하나가 검사 클래스 하나다 |
| `data/compact/` | 원본 결과 파일 8개(176MB)에서 분석이 읽는 필드만 남긴 것(약 10MB) |
| `data/airline/` | 정책, 현행 과제 정의, DB (저장소 커밋 768f3d8) |
| `data/leaderboard_pass1.json` | 리더보드 제출 기록의 airline pass_1 |
| `tools/make_compact.py` | 원본에서 `data/compact`를 다시 만든다 |
| `tools/check_parity.py` | 원본과 줄인 자료에서 같은 수치가 나오는지 확인한다 |
| `tools/test_harness.py` | 손으로 만든 작은 대화로 검사를 시험한다 |
| `validation/delivery_reading/` | 사람 판독 10건: 판독 화면, 가려 둔 키, 첫 답과 최종 답 |
| `validation/cancel_blind_labels/` | 취소 자격 맹검 라벨 59문항: 판독 화면, 문항, 봉인한 규칙 출력, 본인 라벨과 대조 결과 |
| `validation/case_reading/` | 사례 6건과 막힌 쓰기 실행 6개의 본인 판독: 판독 화면, 문항, 본인 답(`case_answers_kkm.json`) |
| `validation/sealed_predictions/` | 보류 파일 3개에 대한 사전 예측과 확인 결과 |
| `validation/replay/` | 실제 airline 도구로 궤적을 다시 실행하는 스크립트와 결과 |
| `validation/tau2_source/` | 노트북이 인용한 tau2-bench 원본 파일 |

## 다시 계산하기

```
python tools/test_harness.py
python tools/check_parity.py data/airline/db.json.gz data/compact
```

원본 결과 파일에서 시작하려면 `data_sources.json`의 URL에서 8개를 받아 한 폴더에 두고 다음을 돌린다.

```
python tools/make_compact.py <원본 폴더> data/compact
python tools/check_parity.py data/airline/db.json.gz <원본 폴더>
```

실제 도구 재생은 저장소 코드와 pydantic이 필요하다. 방법은 `validation/replay/README.md`에 있다.

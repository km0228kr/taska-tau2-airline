"""하네스가 앞서 따로 계산한 수치를 그대로 내는지 확인한다. 하나라도 다르면 멈춘다.

사용법: python tools/check_parity.py <db.json 또는 db.json.gz> <결과 파일 8개가 든 폴더 (원본 .json 또는 data/compact의 .json.gz)>
원본 폴더와 data/compact 폴더에서 각각 돌려 둘 다 통과하면, 줄인 자료가 분석 수치를 바꾸지 않았다는 뜻이다.
"""
import collections, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))   # 한 단계 위 폴더의 하네스를 쓴다
from taska_harness import (Harness, load_runs, read_json, standard_checks, no_action_tasks, CancelRule, IneligibleCancel)
if hasattr(sys.stdout, "reconfigure"): sys.stdout.reconfigure(encoding="utf-8")

db = read_json(sys.argv[1])
runs = load_runs(sys.argv[2])
h = Harness(runs, standard_checks(db))
five = {r["유형"]: r for r in h.summary("분석")}
hold = {r["유형"]: r for r in h.summary("보류")}

def same(label, got, want):
    assert got == want, f"{label}: {got} != {want}"
    print(f"  일치  {label}: {got}")

print("[분석 5개]")
same("실행, 통과", (len([r for r in runs if r.group == "분석"]), five["K1"]["전체_통과"]), (1000, 806))
same("K1 걸림(통과)", (five["K1"]["걸림"], five["K1"]["걸림_통과"]), (527, 420))
same("K2 걸림(통과)", (five["K2"]["걸림"], five["K2"]["걸림_통과"]), (621, 482))
same("K2W-TRY 쓰기 시도 걸림(통과)", (five["K2W-TRY"]["걸림"], five["K2W-TRY"]["걸림_통과"]), (117, 68))
same("K2W 실행된 쓰기 걸림(통과)", (five["K2W"]["걸림"], five["K2W"]["걸림_통과"]), (115, 66))
same("COMM 적용(그중 통과), 걸림(통과)", (five["COMM"]["적용"], five["COMM"]["적용_통과"], five["COMM"]["걸림"], five["COMM"]["걸림_통과"]), (120, 73, 4, 3))
same("COMM-SUB 다른 토큰 안에서만 충족 걸림(통과)", (five["COMM-SUB"]["적용"], five["COMM-SUB"]["걸림"], five["COMM-SUB"]["걸림_통과"]), (120, 1, 1))
same("전달된 메시지에 독립된 수로 나와야 충족으로 본 통과", {m.split("-think")[0]: v for m, v in sorted(h.passes(without=("COMM", "COMM-SUB")).items())},
     {"claude-opus-4-5": 168, "claude-sonnet-4-5": 142, "glm-5": 164, "gpt-5-2": 165, "qwen3.5-397b-a17b": 163})
same("전달된 메시지만 본 문구 판정의 통과", {m.split("-think")[0]: v for m, v in sorted(h.passes(without=("COMM",)).items())},
     {"claude-opus-4-5": 168, "claude-sonnet-4-5": 142, "glm-5": 164, "gpt-5-2": 166, "qwen3.5-397b-a17b": 163})
same("BLOCK 걸림(통과)", (five["BLOCK"]["걸림"], five["BLOCK"]["걸림_통과"]), (24, 14))
same("BLOCK-OFF 정답에 없는 쓰기가 오류로만 막힘 걸림(통과)", (five["BLOCK-OFF"]["걸림"], five["BLOCK-OFF"]["걸림_통과"]), (4, 4))
same("FAIL-OK 적용, 걸림(통과)", (five["FAIL-OK"]["적용"], five["FAIL-OK"]["걸림"], five["FAIL-OK"]["걸림_통과"]), (20, 10, 0))
k1k2 = sum(1 for n, r in enumerate(runs) if r.group == "분석" and r.passed and (h.found["K1"][n] or h.found["K2"][n]))
same("통과 중 K1 또는 K2", k1k2, 630)
cancel = h.checks["CANCEL"]
events = [e for r in runs if r.group == "분석" for e in cancel.events(r)]
same("실행된 취소와 등급", (len(events), dict(sorted(collections.Counter(g for _, g, _ in events).items()))), (216, {"A": 138, "B": 66, "C": 12}))
same("규칙이 잡은 취소", sum(bad for _, _, bad in events), 25)
same("CANCEL 걸린 실행 중 통과", five["CANCEL"]["걸림_통과"], 7)
same("K2 모델별 걸림", {r["모델"].split("-think")[0]: r["걸림"] for r in h.by_model("K2")},
     {"claude-opus-4-5": 179, "claude-sonnet-4-5": 189, "glm-5": 188, "gpt-5-2": 0, "qwen3.5-397b-a17b": 65})
same("규약 강제 판정의 통과", {m.split("-think")[0]: v for m, v in sorted(h.passes(without=("K2",)).items())},
     {"claude-opus-4-5": 20, "claude-sonnet-4-5": 10, "glm-5": 12, "gpt-5-2": 166, "qwen3.5-397b-a17b": 116})
official = h.pairwise(); enforced = h.pairwise(without=("K2",))
same("Holm 0.05 아래인 쌍 (공식, 규약 강제)", (sum(r["holm"] < 0.05 for r in official), sum(r["holm"] < 0.05 for r in enforced)), (0, 7))
same("가장 작은 p (공식)", (official[0]["쌍"], round(official[0]["p"], 4), round(official[0]["holm"], 3)), ("claude-opus-4-5 - claude-sonnet-4-5", 0.0066, 0.066))
same("아무것도 하지 않아도 통과하는 과제 수", len(no_action_tasks([r for r in runs if r.group == "분석"])), 23)
rule = CancelRule(db)
gold = {r.task: rule.flagged_gold_cancels(r.task_def) for r in runs if r.model == "gpt-5-2"}
same("현행 정답에서 규칙이 잡은 취소", {t: v for t, v in gold.items() if v}, {"39": ["MSJ4OA"]})
same("저장된 문구 판정 재현", sum(r.phrases_found(False) == r.comm_stored for r in runs if r.required_phrases), sum(1 for r in runs if r.required_phrases))
print("[보류 3개]")
same("실행, 통과", (len([r for r in runs if r.group == "보류"]), hold["K1"]["전체_통과"]), (597, 456))
same("K2, K2W, COMM 걸림", (hold["K2"]["걸림"], hold["K2W"]["걸림"], hold["COMM"]["걸림"]), (14, 0, 0))
same("COMM-SUB 적용(그중 통과), 걸림(통과)", (hold["COMM-SUB"]["적용"], hold["COMM-SUB"]["적용_통과"], hold["COMM-SUB"]["걸림"], hold["COMM-SUB"]["걸림_통과"]), (72, 35, 1, 1))
t39 = [(n, r) for n, r in enumerate(runs) if r.group == "보류" and r.task == "39"]
same("과제 39: 정책과 일치한 선택인데 실패", (len(t39), sum(bool(h.found["FAIL-OK"][n]) for n, _ in t39)), (11, 9))
print("\n모든 수치가 앞선 계산과 같다.")

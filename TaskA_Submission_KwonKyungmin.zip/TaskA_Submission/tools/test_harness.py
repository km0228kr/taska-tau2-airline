"""하네스의 검사를 손으로 만든 작은 대화로 시험한다. 실제 자료 없이 돈다.

사용법: python tools/test_harness.py
검사마다 '걸려야 하는 예'와 '걸리면 안 되는 예'를 하나 이상 둔다.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))   # 한 단계 위 폴더의 하네스
from taska_harness import (BlockedOffGold, BlockedWrite, CancelRule, DeliveredStandalone, Harness, IneligibleCancel, MultiToolTurn, PhraseOnlyInsideToken, PhraseOnlyUndelivered,
                           ReasonableFailure, Run, TextWithToolCall, TextWithWrite, exact_sign_flip, no_action_tasks)

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


# ---- 손으로 만드는 대화 조각
def user(text):
    return {"role": "user", "content": text}


def agent(text="", calls=()):
    """calls = [(호출 id, 도구 이름, 인자), ...]"""
    return {"role": "assistant", "content": text,
            "tool_calls": [{"id": i, "name": n, "arguments": a} for i, n, a in calls] or None}


def tool(call_id, content="{}", error=False):
    return {"role": "tool", "id": call_id, "content": content, "error": error}


def run(messages, passed=True, gold=(), phrases=(), scenario="", task="1", model="m"):
    task_def = {"evaluation_criteria": {"actions": [{"name": n, "arguments": a} for n, a in gold], "communicate_info": list(phrases)},
                "user_scenario": {"instructions": {"reason_for_call": scenario, "task_instructions": ""}}}
    return Run(model=model, group="분석", task=task, trial=0, passed=passed, messages=messages, task_def=task_def, comm_stored=True)


# ---- 작은 DB: 예약 넷과 항공편 상태
DB = {"flights": {"F1": {"dates": {"2024-05-20": {"status": "available"}, "2024-05-10": {"status": "landed"}}},
                  "F2": {"dates": {"2024-05-20": {"status": "cancelled"}}}},
      "reservations": {
          "BUS": {"created_at": "2024-05-01T10:00:00", "cabin": "business", "insurance": "no", "flights": [{"flight_number": "F1", "date": "2024-05-20"}]},
          "INS": {"created_at": "2024-05-01T10:00:00", "cabin": "economy", "insurance": "yes", "flights": [{"flight_number": "F1", "date": "2024-05-20"}]},
          "NON": {"created_at": "2024-05-01T10:00:00", "cabin": "economy", "insurance": "no", "flights": [{"flight_number": "F1", "date": "2024-05-20"}]},
          "OLD": {"created_at": "2024-05-01T10:00:00", "cabin": "business", "insurance": "yes", "flights": [{"flight_number": "F1", "date": "2024-05-10"}]}}}
RULE = CancelRule(DB)


def cancel_run(rid, said="", passed=True, error=False, **kw):
    state = json.dumps(DB["reservations"][rid])
    return run([user(said), agent(calls=[("c1", "cancel_reservation", {"reservation_id": rid})]), tool("c1", state, error)], passed=passed, **kw)


def test_structure_checks():
    two = run([agent(calls=[("a", "get_user_details", {}), ("b", "get_reservation_details", {})]), tool("a"), tool("b")])
    one = run([agent(calls=[("a", "get_user_details", {})]), tool("a")])
    assert MultiToolTurn().find(two) and not MultiToolTurn().find(one)

    mixed = run([agent("찾아보겠습니다", calls=[("a", "get_user_details", {})]), tool("a")])
    only_text = run([agent("안녕하세요")])
    assert TextWithToolCall().find(mixed) and not TextWithToolCall().find(one) and not TextWithToolCall().find(only_text)

    write_with_text = run([agent("취소하겠습니다", calls=[("a", "cancel_reservation", {"reservation_id": "BUS"})]), tool("a")])
    assert TextWithWrite().find(write_with_text) and not TextWithWrite().find(mixed)     # 조회 호출은 쓰기가 아니다
    blocked_with_text = run([agent("변경하겠습니다", calls=[("a", "update_reservation_flights", {})]), tool("a", "Error: balance", error=True)])
    assert not TextWithWrite().find(blocked_with_text)                                  # 오류로 막힌 쓰기는 실행이 아니다
    assert TextWithWrite(include_blocked=True).find(blocked_with_text)                  # 시도로는 센다

    blocked = run([agent(calls=[("a", "update_reservation_flights", {})]), tool("a", "Error: balance", error=True)])
    assert BlockedWrite().find(blocked) and not BlockedWrite().find(write_with_text)

    off = BlockedOffGold()
    assert off.find(blocked)                                                            # 정답에 없는 쓰기가 막힌 채 끝남
    in_gold = run(blocked.messages, gold=[("update_reservation_flights", {})])
    assert not off.find(in_gold)                                                        # 정답에 있는 종류의 쓰기는 대상이 아니다
    retried = run([agent(calls=[("a", "update_reservation_flights", {"reservation_id": "X"})]), tool("a", "Error: balance", error=True),
                   agent(calls=[("b", "update_reservation_flights", {"reservation_id": "X"})]), tool("b")])
    assert not off.find(retried)                                                        # 다시 시도해 성공했으면 대상이 아니다


def test_phrase_check():
    check = PhraseOnlyUndelivered()
    undelivered = run([agent("합계는 $1,628입니다", calls=[("a", "search_direct_flight", {})]), tool("a"), agent("다른 도움이 필요하신가요?")], phrases=["1628"])
    delivered = run([agent(calls=[("a", "search_direct_flight", {})]), tool("a"), agent("합계는 $1,628입니다")], phrases=["1628"])
    never = run([agent("모르겠습니다")], phrases=["1628"])
    assert check.find(undelivered)                       # 공식 규칙은 충족, 전달된 메시지에는 없음
    assert not check.find(delivered) and not check.find(never)
    assert not check.applies(run([agent("안녕하세요")]))  # 문구 조건이 없는 과제는 분모에서 빠진다

    sub = PhraseOnlyInsideToken()
    in_id = run([agent("사용자 ID를 알려 주세요 (예: sara_doe_496)"), agent("수하물은 1개입니다")], phrases=["4"])
    in_code = run([agent("예약은 CXBB4L, Q4MCUF가 있습니다")], phrases=["4"])
    said = run([agent("예: sara_doe_496"), agent("모두 **4**개까지 됩니다")], phrases=["4"])
    money = run([agent("합계는 $1,000.00입니다")], phrases=["1000"])
    longer = run([agent("합계는 $10,000입니다")], phrases=["1000"])
    assert sub.find(in_id) and sub.find(in_code) and sub.find(longer)   # 공식 규칙은 충족, 독립된 수로는 한 번도 안 나옴
    assert not sub.find(said) and not sub.find(money)                  # 독립된 수로 나왔다. 1000.00은 1000으로 본다
    assert not sub.find(never)                                         # 공식 규칙이 미충족이면 대상이 아니다
    korean = run([agent("수하물은 모두 4개까지 가능합니다")], phrases=["4"])
    korean_id = run([agent("예약번호 Q4MCUF를 확인했습니다")], phrases=["4"])
    assert not sub.find(korean) and sub.find(korean_id)                # 한글 단위가 붙은 수는 독립, 영문 ID 속의 수는 아님

    item1 = DeliveredStandalone()
    split = run([agent("예약번호는 ABC4DEF입니다"), agent("수하물은 4개입니다", calls=[("a", "get_user_details", {})]), tool("a")], phrases=["4"])
    assert not check.find(split) and not sub.find(split)   # 검사 두 개를 합치면 통과로 남는다
    assert item1.find(split)                               # 정의대로면 전달된 메시지에 독립된 4가 없으므로 미충족
    assert not item1.find(said) and item1.find(undelivered) and item1.find(in_id)


def test_cancel_rule():
    grade = lambda rid: RULE.grade(DB["reservations"][rid])
    assert (grade("BUS"), grade("INS"), grade("NON"), grade("OLD")) == ("A", "B", "C", "D")
    recent = dict(DB["reservations"]["NON"], created_at="2024-05-14T16:00:00")           # 23시간 전 예약
    airline_cancelled = dict(DB["reservations"]["NON"], flights=[{"flight_number": "F2", "date": "2024-05-20"}])
    assert RULE.grade(recent) == "A" and RULE.grade(airline_cancelled) == "A"
    assert RULE.covered_reason("I am sick and cannot fly.")
    assert RULE.covered_reason("I'm not feeling well.")
    assert not RULE.covered_reason("I'm not sick, it is just a change of plans.")


def test_cancel_checks():
    check = IneligibleCancel(RULE)
    assert not check.find(cancel_run("BUS"))                          # 비즈니스: 자격 있음
    assert check.find(cancel_run("NON")) and check.find(cancel_run("OLD"))
    assert check.find(cancel_run("INS", said="Change of plans."))      # 보험은 있으나 사유가 건강·날씨가 아님
    assert not check.find(cancel_run("INS", said="I am sick."))
    assert not check.applies(cancel_run("NON", error=True))            # 오류로 끝난 취소는 실행된 취소가 아니다

    gold = [("cancel_reservation", {"reservation_id": "BUS"}), ("cancel_reservation", {"reservation_id": "INS"})]
    assert RULE.flagged_gold_cancels(run([], gold=gold, scenario="I want to give up my seat.").task_def) == ["INS"]
    fail_ok = ReasonableFailure(RULE)
    only_business = cancel_run("BUS", passed=False, gold=gold, scenario="I want to give up my seat.")
    assert fail_ok.applies(only_business) and fail_ok.find(only_business)
    passed_run = cancel_run("BUS", passed=True, gold=gold, scenario="I want to give up my seat.")
    assert not fail_ok.find(passed_run)                                # 통과한 실행은 대상이 아니다
    wrong_target = cancel_run("NON", passed=False, gold=gold, scenario="I want to give up my seat.")
    assert not fail_ok.find(wrong_target)


def test_harness_and_statistics():
    mixed_pass = run([agent("찾아보겠습니다", calls=[("a", "get_user_details", {})]), tool("a")], passed=True, model="A")
    clean_pass = run([agent(calls=[("a", "get_user_details", {})]), tool("a")], passed=True, model="A", task="2")
    clean_fail = run([agent("안녕하세요")], passed=False, model="B")
    h = Harness([mixed_pass, clean_pass, clean_fail], [TextWithToolCall(), PhraseOnlyUndelivered()])
    k2 = [r for r in h.summary() if r["유형"] == "K2"][0]
    assert (k2["적용"], k2["적용_통과"], k2["걸림"], k2["걸림_통과"], k2["전체_통과"]) == (3, 2, 1, 1, 2)
    assert h.passes() == {"A": 2, "B": 0} and h.passes(without=("K2",)) == {"A": 1, "B": 0}
    assert [r["적용"] for r in h.summary() if r["유형"] == "COMM"] == [0]          # 문구 조건이 있는 실행이 없다
    assert len(h.type_table()) == 2 and h.cases("K2")[0][:4] == ("A", "1", 0, True)
    assert no_action_tasks([mixed_pass, clean_pass]) == ["1", "2"]

    assert exact_sign_flip([1, 1, 1]) == 0.25        # 8가지 부호 조합 중 합의 크기가 3 이상인 것은 2가지
    assert exact_sign_flip([2, -2]) == 1.0 and exact_sign_flip([]) == 1.0


if __name__ == "__main__":
    tests = [test_structure_checks, test_phrase_check, test_cancel_rule, test_cancel_checks, test_harness_and_statistics]
    for t in tests:
        t()
        print("통과", t.__name__)
    print(f"시험 {len(tests)}개 모두 통과")

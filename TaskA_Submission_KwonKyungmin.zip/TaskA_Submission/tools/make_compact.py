"""공개 원본 결과 파일에서 분석에 쓰는 필드만 남긴 줄인 자료(data/compact/*.json.gz)를 만든다. 표준 라이브러리만 쓴다.

사용법: python tools/make_compact.py <원본 결과 파일이 든 폴더> [출력 폴더=data/compact]

왜 줄이는가: 원본 8개는 176MB다. 메시지마다 붙은 공급자 원응답(raw_data)과 실행마다 반복되는 정책 전문이 대부분이다.
남기는 것
  파일: info(실행 설정, 정책 전문 1부), tasks(과제 정의 전부)
  실행: id, task_id, trial, seed, termination_reason, reward_info(전부), agent_cost, user_cost, duration
  메시지: role, content, tool_calls, id, error, turn_idx, requestor
버리는 것: raw_data, usage, cost, timestamp, 음성 관련 필드, 실행마다 반복되는 policy, ticks 등 분석이 읽지 않는 필드.
내용을 고치거나 실행을 빼지 않는다. 원본의 SHA-256과 줄인 파일의 SHA-256을 compact_manifest.json에 적는다.
tools/check_parity.py가 원본과 줄인 자료에서 같은 수치가 나오는지 확인한다.
"""
import sys, os, json, gzip, glob, hashlib
if hasattr(sys.stdout, "reconfigure"): sys.stdout.reconfigure(encoding="utf-8")
SRC = sys.argv[1]; OUT = sys.argv[2] if len(sys.argv) > 2 else os.path.join("data", "compact"); os.makedirs(OUT, exist_ok=True)
KEEP_MSG = ("role", "content", "tool_calls", "id", "error", "turn_idx", "requestor")
KEEP_SIM = ("id", "task_id", "trial", "seed", "termination_reason", "reward_info", "agent_cost", "user_cost", "duration")
manifest = []
for path in sorted(glob.glob(os.path.join(SRC, "*.json"))):
    raw = open(path, "rb").read(); d = json.loads(raw)
    out = {"source_file": os.path.basename(path), "source_sha256": hashlib.sha256(raw).hexdigest(), "info": d.get("info"), "tasks": d["tasks"], "simulations": []}
    for s in d["simulations"]:
        sim = {k: s.get(k) for k in KEEP_SIM}
        sim["messages"] = [{k: m[k] for k in KEEP_MSG if k in m} for m in s.get("messages") or []]
        out["simulations"].append(sim)
    body = json.dumps(out, ensure_ascii=False, separators=(",", ":"), sort_keys=True).encode("utf-8")
    dst = os.path.join(OUT, os.path.basename(path) + ".gz")
    with open(dst, "wb") as f:
        with gzip.GzipFile(filename="", mode="wb", fileobj=f, compresslevel=9, mtime=0) as g: g.write(body)   # mtime=0: 다시 만들어도 같은 바이트
    manifest.append(dict(file=os.path.basename(path), source_bytes=len(raw), source_sha256=out["source_sha256"], simulations=len(d["simulations"]),
                         compact_file=os.path.basename(dst), compact_bytes=os.path.getsize(dst), compact_sha256=hashlib.sha256(open(dst, "rb").read()).hexdigest()))
    print(f"{os.path.basename(path):48s} {len(raw) / 1e6:6.1f}MB -> {os.path.getsize(dst) / 1e6:5.2f}MB | 실행 {len(d['simulations'])}")
json.dump(manifest, open(os.path.join(OUT, "compact_manifest.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("합계", round(sum(m["source_bytes"] for m in manifest) / 1e6), "MB ->", round(sum(m["compact_bytes"] for m in manifest) / 1e6, 1), "MB")

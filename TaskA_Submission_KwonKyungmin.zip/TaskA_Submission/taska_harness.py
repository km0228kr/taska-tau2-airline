"""Task A 분석 하네스.

설계는 한 줄이다: 문제 유형 하나 = Check 클래스 하나.
  - 유형의 정의, 판정 기준, 원인 구분은 클래스 속성에 적는다. 5-2의 유형 표는 이 속성을 그대로 출력한 것이다.
  - applies(run)이 분모(어떤 실행에 적용되는가)를, find(run)이 근거(어느 메시지에서 걸렸는가)를 정한다.
  - Harness는 실행을 읽고, 검사를 돌리고, 표를 만든다. 검사를 더하려면 클래스 하나만 더 쓰면 된다.
표준 라이브러리만 쓴다. LLM은 쓰지 않는다. 실제 도구로 DB를 재생하는 검산은 이 파일 밖(validation/sealed_predictions/replay)에 있다.
"""
from __future__ import annotations

import collections
import glob
import gzip
import itertools
import json
import os
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from functools import cached_property

WRITES = {"book_reservation", "cancel_reservation", "send_certificate",
          "update_reservation_baggages", "update_reservation_flights", "update_reservation_passengers"}


def text_of(message) -> str:
    return (message.get("content") or "").strip()


# ---------------------------------------------------------------- 자료 구조
@dataclass
class Call:
    """도구 호출 한 건과 그 결과."""
    index: int        # 이 호출이 든 메시지의 번호
    name: str
    args: dict
    error: bool       # 도구가 오류를 돌려줬는가
    result: str       # 도구가 돌려준 내용
    with_text: bool   # 같은 메시지에 글이 함께 있었는가

    @property
    def is_write(self) -> bool:
        return self.name in WRITES

    @property
    def key(self):
        """호출을 서로 비교하기 위한 값: 이름과 정렬한 인자."""
        return (self.name, json.dumps(self.args, sort_keys=True))


@dataclass
class Run:
    """실행 한 건. 결과 파일의 simulation 하나에 해당한다."""
    model: str
    group: str        # '분석' 또는 '보류'
    task: str
    trial: int
    passed: bool      # 공식 보상이 1인가
    messages: list
    task_def: dict    # 이 파일에 든 과제 정의(정답 행동, 문구 조건, 사용자 시나리오)
    comm_stored: bool  # 파일에 저장된 문구 판정
    reward_info: dict = None   # 파일에 저장된 판정 기록 전체(보상, DB 판정, 문구 판정, 자연어 단언)
    termination: str = ""      # 종료 사유
    file: str = ""             # 결과 파일 이름

    @property
    def db_stored(self) -> bool:
        """파일에 저장된 DB 판정(최종 DB가 정답 행동을 재생한 DB와 같은가)."""
        return bool(((self.reward_info or {}).get("db_check") or {}).get("db_match"))

    @property
    def ended_normally(self) -> bool:
        return str(self.termination).split(".")[-1].lower() in ("agent_stop", "user_stop")

    @cached_property
    def agent(self):
        """(메시지 번호, 메시지) 중 에이전트가 보낸 것."""
        return [(i, m) for i, m in enumerate(self.messages) if m["role"] == "assistant"]

    @cached_property
    def calls(self):
        results = {m.get("id"): m for m in self.messages if m["role"] == "tool"}
        out = []
        for i, m in self.agent:
            for c in m.get("tool_calls") or []:
                r = results.get(c["id"]) or {}
                out.append(Call(i, c["name"], c["arguments"], bool(r.get("error")), str(r.get("content") or ""), bool(text_of(m))))
        return out

    @property
    def gold_writes(self):
        actions = (self.task_def.get("evaluation_criteria") or {}).get("actions") or []
        return [(a["name"], json.dumps(a["arguments"], sort_keys=True)) for a in actions if a["name"] in WRITES]

    @property
    def required_phrases(self):
        return list((self.task_def.get("evaluation_criteria") or {}).get("communicate_info") or [])

    def phrases_found(self, delivered_only: bool) -> bool:
        """공식 문구 규칙: 문구마다 에이전트의 글 어느 하나에 들어 있으면 충족(소문자, 쉼표 제거).
        delivered_only이면 사용자에게 전달된 메시지(도구 호출이 없는 메시지)만 본다."""
        texts = [text_of(m).lower().replace(",", "") for _, m in self.agent
                 if text_of(m) and not (delivered_only and m.get("tool_calls"))]
        return all(any(str(p).lower() in t for t in texts) for p in self.required_phrases)

    def phrase_standalone(self, phrase, delivered_only: bool = False) -> bool:
        """문구가 독립된 토큰으로 나온 적이 있는가(앞뒤 글자가 숫자·영문자·밑줄이 아님. 1000.00의 1000은 독립으로 본다).
        공식 규칙은 이것을 보지 않는다. 그래서 요구 문구 4가 sara_doe_496이나 CXBB4L 안에서도 충족된다.
        경계는 ASCII 글자만 본다. 그래서 한국어처럼 단위가 붙는 경우('4개', '1786달러')도 독립된 수로 본다."""
        tok = lambda ch: ch.isascii() and (ch.isalnum() or ch == "_")
        p = str(phrase).lower()
        for _, m in self.agent:
            t = text_of(m).lower().replace(",", "")
            if not t or (delivered_only and m.get("tool_calls")): continue
            for hit in re.finditer(re.escape(p), t):
                a, b = hit.start(), hit.end()
                before = a > 0 and (tok(t[a - 1]) or (t[a - 1] == "." and a > 1 and t[a - 2].isdigit()))
                after = b < len(t) and tok(t[b])
                if not before and not after: return True
        return False

    def user_said_before(self, index: int) -> str:
        return " ".join(text_of(m) for m in self.messages[:index] if m["role"] == "user")


def read_json(path):
    """.json과 .json.gz를 같은 방식으로 읽는다."""
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8") as f:
        return json.load(f)


def result_files(*paths) -> list:
    """폴더, 파일, * 패턴을 결과 파일 목록으로 푼다."""
    files = []
    for p in paths:
        if os.path.isdir(p):
            files += sorted(glob.glob(os.path.join(p, "*.json")) + glob.glob(os.path.join(p, "*.json.gz")))
        else:
            files += sorted(glob.glob(p)) or [p]
    return [f for f in files if not os.path.basename(f).startswith("compact_manifest")]


def load(*paths, holdout=("gemini", "none")):
    """결과 파일을 읽어 (실행 목록, 파일 정보 목록)을 돌려준다. 보상이 기록되지 않은 실행은 실행 목록에서 빠지고 파일 정보에 수만 남는다.
    holdout에 든 글자가 파일 이름에 있으면 그 파일의 실행은 '보류'로 표시한다(분석에서 뺀 이유는 노트북 3-Q2)."""
    runs, meta = [], []
    for path in result_files(*paths):
        name = os.path.basename(path).replace(".json.gz", "").replace(".json", "")
        data = read_json(path)
        tasks = {str(t["id"]): t for t in data["tasks"]}
        group = "보류" if any(k in name for k in holdout) else "분석"
        model = name.split("_sierra")[0].split("_airline")[0]
        kept = 0
        for s in data["simulations"]:
            info = s.get("reward_info") or {}
            if info.get("reward") is None:
                continue
            kept += 1
            runs.append(Run(model=model, group=group, task=str(s["task_id"]), trial=s.get("trial"), passed=info["reward"] >= 1 - 1e-9,
                            messages=s["messages"], task_def=tasks[str(s["task_id"])],
                            comm_stored=all(c.get("met") for c in (info.get("communicate_checks") or [])),
                            reward_info=info, termination=str(s.get("termination_reason") or ""), file=name))
        fi = data.get("info") or {}
        agent, user = fi.get("agent_info") or {}, fi.get("user_info") or {}
        meta.append(dict(file=name, model=model, group=group, simulations=len(data["simulations"]), with_reward=kept, tasks=len(tasks),
                         git_commit=fi.get("git_commit"), agent_llm=agent.get("llm"), agent_args=agent.get("llm_args"),
                         user_llm=user.get("llm"), user_args=user.get("llm_args"), seed=fi.get("seed"),
                         policy=((fi.get("environment_info") or {}).get("policy") or ""), source_sha256=data.get("source_sha256")))
    return runs, meta


def load_runs(*paths, holdout=("gemini", "none")) -> list[Run]:
    """결과 파일(또는 폴더, 또는 * 패턴)을 읽어 보상이 기록된 실행만 돌려준다."""
    return load(*paths, holdout=holdout)[0]


# ---------------------------------------------------------------- 검사의 공통 틀
class Check:
    """문제 유형 하나. 하위 클래스는 속성 넷과 find()를 채운다."""
    id = ""
    name = ""
    rule = ""     # 판정 기준
    cause = ""    # 원인 구분: 모델 / 벤치마크 정답·환경 / 판정 로직
    scope = "모든 실행"

    def applies(self, run: Run) -> bool:
        return True

    def find(self, run: Run) -> list:
        """걸린 근거의 목록 [(메시지 번호, 설명), ...]. 비어 있으면 이 실행은 걸리지 않은 것이다."""
        raise NotImplementedError


# ---------------------------------------------------------------- 절차 조항 (메시지 구조만 본다)
class MultiToolTurn(Check):
    id, name = "K1", "한 메시지에 도구 호출 여러 개"
    rule = "에이전트 메시지 하나에 도구 호출이 2개 이상 (정책: only make one tool call at a time)"
    cause = "모델 / 판정 로직(검사 없음)"

    def find(self, run):
        return [(i, f"호출 {len(m['tool_calls'])}개") for i, m in run.agent if len(m.get("tool_calls") or []) >= 2]


class TextWithToolCall(Check):
    id, name = "K2", "도구 호출과 글을 한 메시지에"
    rule = "도구 호출이 든 에이전트 메시지에 글이 있음. 이 글은 사용자에게 전달되지 않는다 (tau2의 규약 검사는 기본값이 꺼짐)"
    cause = "모델 / 판정 로직(검사 꺼짐)"

    def find(self, run):
        return [(i, text_of(m)[:80]) for i, m in run.agent if m.get("tool_calls") and text_of(m)]


class TextWithWrite(Check):
    """K2 메시지에 든 쓰기 호출. 기본은 오류 없이 실행된 것만 센다. include_blocked=True이면 오류로 막힌 시도까지 센다."""
    cause = "모델 / 판정 로직(검사 꺼짐)"

    def __init__(self, include_blocked=False):
        self.include_blocked = include_blocked
        if include_blocked:
            self.id, self.name = "K2W-TRY", "보지 못한 글과 함께 시도된 쓰기"
            self.rule = "K2 메시지에 쓰기 호출이 있음 (도구 오류로 막힌 것 포함)"
        else:
            self.id, self.name = "K2W", "보지 못한 글과 함께 실행된 쓰기"
            self.rule = "K2 메시지에 든 쓰기 호출이 오류 없이 실행됨"

    def find(self, run):
        return [(c.index, c.name) for c in run.calls if c.is_write and c.with_text and (self.include_blocked or not c.error)]


class PhraseOnlyUndelivered(Check):
    id, name = "COMM", "전달 안 된 글로 문구 충족"
    rule = "공식 문구 규칙은 충족인데, 사용자에게 전달된 메시지만 보면 충족되지 않음"
    cause = "판정 로직"
    scope = "문구 조건이 있는 실행"

    def applies(self, run):
        return bool(run.required_phrases)

    def find(self, run):
        if run.phrases_found(delivered_only=False) and not run.phrases_found(delivered_only=True):
            return [(-1, f"요구 문구 {run.required_phrases}")]
        return []


class PhraseOnlyInsideToken(Check):
    id, name = "COMM-SUB", "다른 토큰 안의 글자로 문구 충족"
    rule = "공식 문구 규칙은 충족인데, 요구 문구가 독립된 수로 나온 곳이 에이전트의 글 어디에도 없음 (예: 4가 sara_doe_496 안에서만 나옴)"
    cause = "판정 로직. 그 실행에서 답이 틀렸거나 빠진 것은 모델"
    scope = "문구 조건이 있는 실행"

    def applies(self, run):
        return bool(run.required_phrases)

    def find(self, run):
        if not run.phrases_found(delivered_only=False): return []
        return [(-1, f"요구 문구 {p}") for p in run.required_phrases if not run.phrase_standalone(p)]


class DeliveredStandalone(Check):
    """6-2 항목 1을 정의 그대로 계산한다. COMM과 COMM-SUB는 조건을 하나씩만 풀어 보므로, 둘을 합쳐도
    '같은 전달 메시지 안에 독립된 수'를 보장하지 않는다(전달된 'ABC4DEF'와 전달되지 않은 '4개'가 함께 있으면 둘 다 안 걸린다)."""
    id, name = "항목1", "전달된 메시지에 독립된 수로 나온 요구 문구가 없음"
    rule = "요구 문구마다, 도구 호출이 없는 상담원 메시지 하나에 독립된 수로 나와야 충족 (6-2 항목 1)"
    cause = "판정 로직(제안한 보완 판정)"
    scope = "문구 조건이 있는 실행"

    def applies(self, run):
        return bool(run.required_phrases)

    def find(self, run):
        return [(-1, f"요구 문구 {p}") for p in run.required_phrases if not run.phrase_standalone(p, delivered_only=True)]


class BlockedWrite(Check):
    id, name = "BLOCK", "막힌 쓰기"
    rule = "쓰기 호출이 도구 오류로 끝남 (과제 양식 cell-00의 예시 유형)"
    cause = "벤치마크 환경이 막음 / 판정은 구분하지 못함"

    def find(self, run):
        return [(c.index, f"{c.name}: {c.result[:60]}") for c in run.calls if c.is_write and c.error]


class BlockedOffGold(Check):
    id, name = "BLOCK-OFF", "정답에 없는 쓰기가 도구 오류로만 막힘"
    rule = "오류로 끝난 쓰기 호출이 뒤에서 다시 성공하지 않았고, 그 도구가 정답 행동에 없는 종류임 (도구 이름만 비교하므로, 맞는 도구를 다른 예약에 쓴 경우는 잡지 않는다)"
    cause = "모델(하지 말아야 할 쓰기를 시도) / 판정 로직(환경이 막은 것을 구분하지 못함)"

    def find(self, run):
        gold = {w[0] for w in run.gold_writes}
        out = []
        for c in run.calls:
            if not (c.is_write and c.error) or c.name in gold:
                continue
            rid = c.args.get("reservation_id")
            if any(d.index > c.index and d.name == c.name and d.args.get("reservation_id") == rid and not d.error for d in run.calls):
                continue
            out.append((c.index, f"{c.name}: {c.result[:60]}"))
        return out


# ---------------------------------------------------------------- 취소 자격 (예약 상태와 사용자 사유를 본다)
class CancelRule:
    """정책 'Cancel flight' 절. D 이미 비행 / A 자격 있음 / B 보험만 있음(사유가 건강·날씨여야 함) / C 자격 없음."""
    NOW = datetime(2024, 5, 15, 15, 0, 0)   # 정책 머리말의 현재 시각
    HEALTH_WEATHER = re.compile(r"\b(sick|ill|illness|health|medical|unwell|doctor|hospital|surgery|injur\w*|covid|flu|fever|"
                                r"weather|storm|snow|hurricane|blizzard)\b|not feeling well", re.I)
    NEGATION = re.compile(r"\b(not|no|nothing|neither|isn't|healthy)\b", re.I)

    def __init__(self, db: dict):
        self.db = db

    def grade(self, reservation: dict) -> str:
        flights = reservation["flights"]
        status = [self.db["flights"][f["flight_number"]]["dates"].get(f["date"], {}).get("status") for f in flights]
        flown = any(s in ("landed", "flying") for s in status) or any(
            f["date"] < "2024-05-15" and s != "cancelled" for f, s in zip(flights, status))
        if flown:
            return "D"
        within_24h = self.NOW - datetime.fromisoformat(reservation["created_at"]) <= timedelta(hours=24)
        if within_24h or reservation["cabin"] == "business" or any(s == "cancelled" for s in status):
            return "A"
        return "B" if reservation.get("insurance") == "yes" else "C"

    def covered_reason(self, user_text: str) -> str:
        """사용자 발화에서 부정어 없이 건강·날씨를 말한 문장. 영어 키워드에 기대는 유일한 부분이다."""
        for sentence in re.split(r"(?<=[.!?])\s+", user_text):
            if self.HEALTH_WEATHER.search(sentence) and (not self.NEGATION.search(sentence) or "not feeling well" in sentence.lower()):
                return sentence.strip()
        return ""

    def ineligible(self, reservation: dict, user_text: str) -> bool:
        g = self.grade(reservation)
        return g in "CD" or (g == "B" and not self.covered_reason(user_text))

    def flagged_gold_cancels(self, task_def: dict) -> list:
        """정답 행동 중 이 규칙이 잡는 취소의 예약 번호. 정답 안의 앞선 좌석 변경을 반영한다."""
        ins = (task_def.get("user_scenario") or {}).get("instructions") or {}
        scenario = " ".join(str(ins.get(k) or "") for k in ("reason_for_call", "task_instructions")) if isinstance(ins, dict) else str(ins)
        state, flagged = {}, []
        for a in (task_def.get("evaluation_criteria") or {}).get("actions") or []:
            rid = (a.get("arguments") or {}).get("reservation_id")
            if a["name"] == "update_reservation_flights" and rid in self.db["reservations"]:
                r = dict(state.get(rid) or self.db["reservations"][rid])
                r["cabin"] = a["arguments"].get("cabin", r["cabin"])
                r["flights"] = a["arguments"].get("flights") or r["flights"]
                state[rid] = r
            if a["name"] == "cancel_reservation" and self.ineligible(state.get(rid) or self.db["reservations"][rid], scenario):
                flagged.append(rid)
        return flagged


class IneligibleCancel(Check):
    id, name = "CANCEL", "자격 근거가 확인되지 않는 취소"
    rule = ("오류 없이 실행된 취소의 직전 예약 상태가 등급 C·D이거나(관측 사실과 충돌), "
            "등급 B인데 건강·날씨 사유 문장이 잡히지 않음(충돌 또는 사유 미확립. 이 둘은 원문을 읽어야 갈린다)")
    cause = "모델 / 벤치마크 정답(정답이 그 취소를 요구할 때)"
    scope = "취소를 실행한 실행"

    def __init__(self, rule: CancelRule):
        self.cancel_rule = rule

    def events(self, run):
        """실행된 취소마다 (호출, 등급, 자격 없음 여부). 취소 호출이 돌려준 예약 상태로 판정한다."""
        out = []
        for c in run.calls:
            if c.name == "cancel_reservation" and not c.error:
                state = json.loads(c.result)
                said = run.user_said_before(c.index)
                out.append((c, self.cancel_rule.grade(state), self.cancel_rule.ineligible(state, said)))
        return out

    def applies(self, run):
        return bool(self.events(run))

    def find(self, run):
        return [(c.index, f"{c.args.get('reservation_id')} 등급 {g}") for c, g, bad in self.events(run) if bad]


class ReasonableFailure(Check):
    id, name = "FAIL-OK", "정책과 일치한 선택인데 실패"
    rule = "실패한 실행의 쓰기가, 정답에서 규칙이 잡은 취소만 뺀 것과 같음"
    cause = "벤치마크 정답"
    scope = "정답에 규칙이 잡는 취소가 든 과제의 실행"

    def __init__(self, rule: CancelRule):
        self.cancel_rule = rule

    def applies(self, run):
        return bool(self.cancel_rule.flagged_gold_cancels(run.task_def))

    def find(self, run):
        if run.passed:
            return []
        flagged = set(self.cancel_rule.flagged_gold_cancels(run.task_def))
        wanted = sorted(w for w in run.gold_writes if not (w[0] == "cancel_reservation" and json.loads(w[1])["reservation_id"] in flagged))
        did = sorted(c.key for c in run.calls if c.is_write and not c.error)
        return [(-1, f"정답에서 {sorted(flagged)} 취소만 빼면 실행한 쓰기와 같다")] if did == wanted else []


# ---------------------------------------------------------------- 하네스
class Harness:
    """실행 목록에 검사 목록을 돌리고 표를 만든다."""

    def __init__(self, runs: list, checks: list):
        self.runs = runs
        self.checks = {c.id: c for c in checks}
        # found[검사 id][실행 번호] = 근거 목록 (적용 대상이 아니면 None)
        self.found = {c.id: [c.find(r) if c.applies(r) else None for r in runs] for c in checks}

    def add(self, check):
        """검사를 나중에 더한다. 앞에서 만든 표에는 들어가지 않는다."""
        self.checks[check.id] = check
        self.found[check.id] = [check.find(r) if check.applies(r) else None for r in self.runs]

    def _pick(self, group):
        return [n for n, r in enumerate(self.runs) if group is None or r.group == group]

    def type_table(self):
        """5-2의 유형 표: 검사 클래스의 속성을 그대로 낸다."""
        return [dict(유형=c.id, 이름=c.name, 판정기준=c.rule, 적용대상=c.scope, 원인=c.cause) for c in self.checks.values()]

    def summary(self, group="분석"):
        """검사마다: 적용 대상 실행 수와 그중 통과(분모), 걸린 실행 수와 그중 통과. 검사끼리는 단위와 분모가 달라 합치지 않는다."""
        idx = self._pick(group)
        rows = []
        for cid, found in self.found.items():
            applied = [n for n in idx if found[n] is not None]
            flagged = [n for n in applied if found[n]]
            rows.append(dict(유형=cid, 이름=self.checks[cid].name, 적용=len(applied), 적용_통과=sum(self.runs[n].passed for n in applied),
                             걸림=len(flagged), 걸림_통과=sum(self.runs[n].passed for n in flagged),
                             전체_통과=sum(self.runs[n].passed for n in idx)))
        return rows

    def by_model(self, check_id, group="분석"):
        rows = []
        for model in sorted({self.runs[n].model for n in self._pick(group)}):
            idx = [n for n in self._pick(group) if self.runs[n].model == model]
            flagged = [n for n in idx if self.found[check_id][n]]
            rows.append(dict(모델=model, 실행=len(idx), 통과=sum(self.runs[n].passed for n in idx),
                             걸림=len(flagged), 걸림_통과=sum(self.runs[n].passed for n in flagged)))
        return rows

    def passes(self, without=(), group="분석"):
        """모델별 통과 수. without에 든 검사에 걸린 실행은 통과에서 뺀다 (판정만 바꿔 다시 세는 민감도 계산)."""
        out = collections.Counter()
        for n in self._pick(group):
            r = self.runs[n]
            out[r.model] += int(r.passed and not any(self.found[c][n] for c in without))
        return dict(out)

    def cases(self, check_id, group="분석", limit=5):
        """걸린 실행의 (모델, 과제, 반복, 공식 통과, 근거)."""
        hits = [(self.runs[n], self.found[check_id][n]) for n in self._pick(group) if self.found[check_id][n]]
        return [(r.model, r.task, r.trial, r.passed, ev[:3]) for r, ev in hits[:limit]]

    def pairwise(self, without=(), group="분석"):
        """모델 쌍마다 과제 단위 정확 부호 뒤집기 검정과 Holm 보정."""
        per = collections.defaultdict(lambda: collections.Counter())   # per[모델][과제] = 통과 수
        size = collections.Counter()
        for n in self._pick(group):
            r = self.runs[n]
            size[r.model] += 1
            per[r.model][r.task] += int(r.passed and not any(self.found[c][n] for c in without))
        tasks = sorted({t for m in per for t in per[m]}, key=int)
        rows = []
        for a, b in itertools.combinations(sorted(per, key=lambda m: -sum(per[m].values())), 2):
            diffs = [per[a][t] - per[b][t] for t in tasks]
            gap = 100 * (sum(per[a].values()) / size[a] - sum(per[b].values()) / size[b])
            rows.append(dict(쌍=f"{a} - {b}", 차이=round(gap, 1), p=exact_sign_flip(diffs)))
        rows.sort(key=lambda r: r["p"])
        running = 0.0
        for k, r in enumerate(rows):                      # Holm: 작은 p부터 (쌍 수 - 순위)를 곱하고 단조 증가로 만든다
            running = min(1.0, max(running, (len(rows) - k) * r["p"]))
            r["holm"] = running
        return rows

    @staticmethod
    def flow(run: Run, width=0, pick=None, agent_width=0):
        """사례 발췌: 누가 누구에게 보냈는가. 도구 호출이 든 메시지의 글은 사용자에게 가지 않는다.
        width=0이면 자르지 않는다. 자르면 판단에 필요한 문장(조건부 승인 등)이 빠질 수 있다.
        agent_width를 주면 상담원 메시지만 그 길이로 자른다. 사용자 메시지는 자르지 않는다.
        pick에 메시지 번호를 주면 그 메시지만 보이고, 건너뛴 곳은 '…'로 표시한다(도구 결과 메시지는 항상 뺀다)."""
        errors = {(c.index, c.name): c.error for c in run.calls}
        lines = [f"{run.model} 과제 {run.task} 반복 {run.trial} | 공식 통과 {run.passed} | 메시지 {len(run.messages)}개"]
        last = -1
        for i, m in enumerate(run.messages):
            if pick is not None and i not in pick:
                continue
            if pick is not None and m["role"] != "tool" and i > last + 1 and last >= 0:
                lines.append("     …")
            last = i
            t = text_of(m).replace("\n", " ")
            t = t[:width] if width else t
            if agent_width and m["role"] == "assistant" and len(t) > agent_width:
                t = t[:agent_width] + f" …(뒤 {len(t) - agent_width}자 생략)"
            if m["role"] == "user":
                lines.append(f"[{i:2d}] 사용자: {t}")
            elif m["role"] == "assistant" and m.get("tool_calls"):
                names = ", ".join(c["name"] + ("(오류)" if errors.get((i, c["name"])) else "") for c in m["tool_calls"])
                lines.append(f"[{i:2d}] 상담원 → 도구 (사용자에게 전달 안 됨) | 호출: {names}" + (f" | 함께 보낸 글: {t}" if t else ""))
            elif m["role"] == "assistant":
                lines.append(f"[{i:2d}] 상담원 → 사용자: {t}")
        return "\n".join(lines)


class Table:
    """표 출력. Jupyter에서는 HTML 표로, 그 밖에서는 글자 표로 보인다. rows는 dict의 목록이다."""

    def __init__(self, rows, title=""):
        self.rows = [dict(r) for r in rows]
        self.title = title

    def _cols(self):
        cols = []
        for r in self.rows:
            cols += [k for k in r if k not in cols]
        return cols

    @staticmethod
    def _fmt(v):
        if isinstance(v, float):
            return f"{v:.3g}" if abs(v) < 0.01 and v != 0 else f"{v:.1f}" if abs(v) >= 1 else f"{v:.3f}".rstrip("0").rstrip(".")
        return "" if v is None else str(v)

    def _repr_html_(self):
        import html as _h
        cols = self._cols()
        head = "".join(f"<th style='text-align:left'>{_h.escape(str(c))}</th>" for c in cols)
        body = "".join("<tr>" + "".join(f"<td style='text-align:left'>{_h.escape(self._fmt(r.get(c)))}</td>" for c in cols) + "</tr>" for r in self.rows)
        cap = f"<caption style='text-align:left;font-weight:600'>{_h.escape(self.title)}</caption>" if self.title else ""
        return f"<table>{cap}<thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>"

    def __repr__(self):
        import unicodedata
        width = lambda s: sum(2 if unicodedata.east_asian_width(ch) in "WF" else 1 for ch in s)
        cols = self._cols()
        cells = [[str(c) for c in cols]] + [[self._fmt(r.get(c)) for c in cols] for r in self.rows]
        w = [max(width(row[k]) for row in cells) for k in range(len(cols))]
        pad = lambda s, n: s + " " * (n - width(s))
        out = [self.title] if self.title else []
        for n, row in enumerate(cells):
            out.append("  ".join(pad(x, w[k]) for k, x in enumerate(row)))
            if n == 0:
                out.append("  ".join("-" * w[k] for k in range(len(cols))))
        return "\n".join(out)


def pass_hat_k(passes: list, k: int) -> float:
    """과제 하나의 반복 결과(0/1 목록)에서 pass^k: k번을 뽑았을 때 모두 통과할 확률 C(c,k)/C(n,k)."""
    import math
    n, c = len(passes), sum(passes)
    return math.comb(c, k) / math.comb(n, k) if n >= k else float("nan")


def rank(values) -> list:
    """평균 순위(같은 값은 순위를 나눠 가진다)."""
    order = sorted(range(len(values)), key=lambda i: values[i])
    out = [0.0] * len(values)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and values[order[j + 1]] == values[order[i]]:
            j += 1
        for k in range(i, j + 1):
            out[order[k]] = (i + j) / 2 + 1
        i = j + 1
    return out


def spearman(a, b) -> float:
    ra, rb = rank(a), rank(b)
    n = len(a)
    ma, mb = sum(ra) / n, sum(rb) / n
    num = sum((x - ma) * (y - mb) for x, y in zip(ra, rb))
    den = (sum((x - ma) ** 2 for x in ra) * sum((y - mb) ** 2 for y in rb)) ** 0.5
    return num / den if den else float("nan")


def no_action_tasks(runs) -> list:
    """정답에 쓰기도 문구 조건도 없는 과제. 아무것도 하지 않아도 DB 항과 문구 항을 통과한다."""
    seen = {r.task: r for r in runs}
    return sorted((t for t, r in seen.items() if not r.gold_writes and not r.required_phrases), key=int)


def exact_sign_flip(diffs) -> float:
    """과제별 차이의 부호를 과제마다 뒤집은 2^n가지 합 가운데, 관측한 합만큼 크거나 더 큰 것의 비율."""
    diffs = [int(d) for d in diffs if d != 0]
    observed = abs(sum(diffs))
    ways = {0: 1}
    for d in diffs:
        nxt = collections.Counter()
        for total, w in ways.items():
            nxt[total + d] += w
            nxt[total - d] += w
        ways = nxt
    return sum(w for total, w in ways.items() if abs(total) >= observed) / sum(ways.values())


def standard_checks(db: dict) -> list:
    rule = CancelRule(db)
    return [MultiToolTurn(), TextWithToolCall(), TextWithWrite(include_blocked=True), TextWithWrite(), PhraseOnlyUndelivered(),
            PhraseOnlyInsideToken(), BlockedWrite(), BlockedOffGold(), IneligibleCancel(rule), ReasonableFailure(rule)]